package text.bwei.com.wuzijingdouyin.view;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import text.bwei.com.wuzijingdouyin.R;

//import text.bwei.com.toutiao.R;

//import com.example.asus.douyinapp.R;


public class ReleaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_release2);

    }
}
