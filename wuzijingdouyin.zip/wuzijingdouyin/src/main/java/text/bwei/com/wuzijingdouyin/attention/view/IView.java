package text.bwei.com.wuzijingdouyin.attention.view;



public interface IView {

}
