package text.bwei.com.wuzijingdouyin.attention.utils;



public interface RetiofitVpi {

}
