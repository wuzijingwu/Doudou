package text.bwei.com.wuzijingdouyin.attention.utils;



public class Constants {

    public static final String BASE_URL = "https://api.amemv.com/";

}
