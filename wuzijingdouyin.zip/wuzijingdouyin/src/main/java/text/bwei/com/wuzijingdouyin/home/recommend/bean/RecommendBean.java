package text.bwei.com.wuzijingdouyin.home.recommend.bean;

import java.util.List;


public class RecommendBean {

    /**
     * category_list : [{"challenge_info":{"schema":"aweme://aweme/challenge/detail?cid=1591086229599236","user_count":16,"author":{},"cha_name":"请你跟我这样做","cid":"1591086229599236","type":0,"desc":"不管你是民族舞小仙女，还是漫画小能手，或者你会钢琴跆拳道花式篮球\u2026\u2026小时候麻麻逼我们学的课外兴趣特长终于有用武之地啦！快来秀出你的独门绝技，请大家跟你一起做，看看你的粉丝有几个能做到并@你的吧！"},"aweme_list":[{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":57823035328,"rate":12,"create_time":1517379483,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"6bd1cb90f361468497047aba1d465053"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5efd00112f956366450f.jpeg","https://pb9.pstatp.com/aweme/300x400/5efd00112f956366450f.jpeg","https://pb3.pstatp.com/aweme/300x400/5efd00112f956366450f.jpeg"],"uri":"300x400/5efd00112f956366450f"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"6bd1cb90f361468497047aba1d465053"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5efd00113018f94ddd70.jpeg","http://pb9.pstatp.com/large/5efd00113018f94ddd70.jpeg","http://pb3.pstatp.com/large/5efd00113018f94ddd70.jpeg"],"uri":"large/5efd00113018f94ddd70"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"6bd1cb90f361468497047aba1d465053"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/5f0300005889719acc57","https://pb3.pstatp.com/obj/5f0300005889719acc57","https://pb3.pstatp.com/obj/5f0300005889719acc57"],"uri":"5f0300005889719acc57"}},"aweme_id":"6517093468668431619","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":264154,"aweme_id":"6517093468668431619","comment_count":46,"share_count":241,"digg_count":7574},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6517093468668431619/?mid=6517078237074426637","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6517093468668431619/?region=CN&mid=6517078237074426637","share_desc":"办公室瘦腿大法！请你像我这样做 四个动作 每组1分钟😉 懒人瘦腿必备～ 学会的宝贝记得发视频艾特我交作业哦！"},"is_top":0,"aweme_type":0,"desc":"办公室瘦腿大法！请你像我这样做 四个动作 每组1分钟😉 懒人瘦腿必备～ 学会的宝贝记得发视频艾特我交作业哦！","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":59048261498,"rate":12,"create_time":1517379227,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=719a815b5c10443c8d8a159bba176701&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=719a815b5c10443c8d8a159bba176701&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"719a815b5c10443c8d8a159bba176701"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5efd0010939dd120685f.jpeg","https://pb9.pstatp.com/aweme/300x400/5efd0010939dd120685f.jpeg","https://pb3.pstatp.com/aweme/300x400/5efd0010939dd120685f.jpeg"],"uri":"300x400/5efd0010939dd120685f"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=719a815b5c10443c8d8a159bba176701&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=719a815b5c10443c8d8a159bba176701&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"719a815b5c10443c8d8a159bba176701"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5f010001af17ea6d2d03.jpeg","http://pb9.pstatp.com/large/5f010001af17ea6d2d03.jpeg","http://pb3.pstatp.com/large/5f010001af17ea6d2d03.jpeg"],"uri":"large/5f010001af17ea6d2d03"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=719a815b5c10443c8d8a159bba176701&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=719a815b5c10443c8d8a159bba176701&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"719a815b5c10443c8d8a159bba176701"},"dynamic_cover":{"url_list":["https://p3.pstatp.com/obj/5efe000a5c80f2337cc4","https://pb9.pstatp.com/obj/5efe000a5c80f2337cc4","https://pb3.pstatp.com/obj/5efe000a5c80f2337cc4"],"uri":"5efe000a5c80f2337cc4"}},"aweme_id":"6517094134409334019","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":396395,"aweme_id":"6517094134409334019","comment_count":953,"share_count":153,"digg_count":20994},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6517094134409334019/?mid=6469589389843860237","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6517094134409334019/?region=CN&mid=6469589389843860237","share_desc":"据说好看的人一秒就会。反正我研究了半天😂你花了几秒钟看会的？如果你会就拍个视频艾特我呗🤔我估计你们都会😂"},"is_top":0,"aweme_type":0,"desc":"据说好看的人一秒就会。反正我研究了半天😂你花了几秒钟看会的？如果你会就拍个视频艾特我呗🤔我估计你们都会😂","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":58961282104,"rate":12,"create_time":1517387004,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=4eafb72dbfce413597861dd9941e7df8&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=4eafb72dbfce413597861dd9941e7df8&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"4eafb72dbfce413597861dd9941e7df8"},"cover":{"url_list":["https://p1.pstatp.com/aweme/300x400/5f00001293d9f1d274ae.jpeg","https://pb3.pstatp.com/aweme/300x400/5f00001293d9f1d274ae.jpeg","https://pb3.pstatp.com/aweme/300x400/5f00001293d9f1d274ae.jpeg"],"uri":"300x400/5f00001293d9f1d274ae"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=4eafb72dbfce413597861dd9941e7df8&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=4eafb72dbfce413597861dd9941e7df8&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"4eafb72dbfce413597861dd9941e7df8"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5f0700011b902819cc08.jpeg","http://pb9.pstatp.com/large/5f0700011b902819cc08.jpeg","http://pb3.pstatp.com/large/5f0700011b902819cc08.jpeg"],"uri":"large/5f0700011b902819cc08"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=4eafb72dbfce413597861dd9941e7df8&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=4eafb72dbfce413597861dd9941e7df8&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"4eafb72dbfce413597861dd9941e7df8"},"dynamic_cover":{"url_list":["https://p3.pstatp.com/obj/5f04001055b08f18849e","https://pb9.pstatp.com/obj/5f04001055b08f18849e","https://pb3.pstatp.com/obj/5f04001055b08f18849e"],"uri":"5f04001055b08f18849e"}},"aweme_id":"6517127447316532487","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":22360,"aweme_id":"6517127447316532487","comment_count":98,"share_count":11,"digg_count":349},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6517127447316532487/?mid=6511486777277352708","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6517127447316532487/?region=CN&mid=6511486777277352708","share_desc":"请你跟我这样做，你能做到第几个？评论1 2 3 4 5或者拍视频艾特我证明自己吧！"},"is_top":0,"aweme_type":0,"desc":"请你跟我这样做，你能做到第几个？评论1 2 3 4 5或者拍视频艾特我证明自己吧！","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":58708324458,"rate":12,"create_time":1517381742,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=8e5bd060e7d24ae685359a2c5b72a64e&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=8e5bd060e7d24ae685359a2c5b72a64e&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"8e5bd060e7d24ae685359a2c5b72a64e"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5f020002c97f8150a21f.jpeg","https://pb9.pstatp.com/aweme/300x400/5f020002c97f8150a21f.jpeg","https://pb3.pstatp.com/aweme/300x400/5f020002c97f8150a21f.jpeg"],"uri":"300x400/5f020002c97f8150a21f"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=8e5bd060e7d24ae685359a2c5b72a64e&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=8e5bd060e7d24ae685359a2c5b72a64e&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"8e5bd060e7d24ae685359a2c5b72a64e"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5f010007d4e15fd2c3ab.jpeg","http://pb9.pstatp.com/large/5f010007d4e15fd2c3ab.jpeg","http://pb3.pstatp.com/large/5f010007d4e15fd2c3ab.jpeg"],"uri":"large/5f010007d4e15fd2c3ab"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=8e5bd060e7d24ae685359a2c5b72a64e&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=8e5bd060e7d24ae685359a2c5b72a64e&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"8e5bd060e7d24ae685359a2c5b72a64e"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/5f030005e560ca86897f","https://pb3.pstatp.com/obj/5f030005e560ca86897f","https://pb3.pstatp.com/obj/5f030005e560ca86897f"],"uri":"5f030005e560ca86897f"}},"aweme_id":"6517104895693163779","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":19049,"aweme_id":"6517104895693163779","comment_count":109,"share_count":9,"digg_count":457},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6517104895693163779/?mid=6517104959136205576","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6517104895693163779/?region=CN&mid=6517104959136205576","share_desc":"连麦嘛 我抖音（你们那里今天出太阳了吗？）"},"is_top":0,"aweme_type":0,"desc":"连麦嘛 我抖音（你们那里今天出太阳了吗？）","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":76055758243,"rate":0,"create_time":1517381151,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=048a2b9bbbf84c95a55dd6a8f27ea7a7&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=048a2b9bbbf84c95a55dd6a8f27ea7a7&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"048a2b9bbbf84c95a55dd6a8f27ea7a7"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5efe000f09fdb2ccfabd.jpeg","https://pb9.pstatp.com/aweme/300x400/5efe000f09fdb2ccfabd.jpeg","https://pb3.pstatp.com/aweme/300x400/5efe000f09fdb2ccfabd.jpeg"],"uri":"300x400/5efe000f09fdb2ccfabd"},"height":540,"width":960,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=048a2b9bbbf84c95a55dd6a8f27ea7a7&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=048a2b9bbbf84c95a55dd6a8f27ea7a7&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"048a2b9bbbf84c95a55dd6a8f27ea7a7"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5f030004707859ad6a4d.jpeg","http://pb9.pstatp.com/large/5f030004707859ad6a4d.jpeg","http://pb3.pstatp.com/large/5f030004707859ad6a4d.jpeg"],"uri":"large/5f030004707859ad6a4d"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=048a2b9bbbf84c95a55dd6a8f27ea7a7&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=048a2b9bbbf84c95a55dd6a8f27ea7a7&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"048a2b9bbbf84c95a55dd6a8f27ea7a7"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/5f040001eacf7547883c","https://pb3.pstatp.com/obj/5f040001eacf7547883c","https://pb3.pstatp.com/obj/5f040001eacf7547883c"],"uri":"5f040001eacf7547883c"}},"aweme_id":"6517102359686941956","video_labels":[{"label_type":3,"label_url":{"url_list":["https://p1.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7"],"uri":"330a000f6d4569feb2f7"}}],"is_vr":false,"vr_type":1,"statistics":{"play_count":914508,"aweme_id":"6517102359686941956","comment_count":451,"share_count":542,"digg_count":39968},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6517102359686941956/?mid=6517102446186400516","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p1.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7"],"uri":"330a000f6d4569feb2f7"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6517102359686941956/?region=CN&mid=6517102446186400516","share_desc":"一禅能用编钟敲超级玛丽哦~你又能用什么东西来演奏呢？来和一禅一起演奏吧，别忘了艾特一禅噢！（顺便求个小心心~）"},"is_top":0,"label_thumb":{"url_list":["https://p1.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2"],"uri":"2efe004a4a7dc47b3bc2"},"aweme_type":0,"desc":"一禅能用编钟敲超级玛丽哦~你又能用什么东西来演奏呢？来和一禅一起演奏吧，别忘了艾特一禅噢！（顺便求个小心心~）","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":57757215586,"rate":12,"create_time":1517392896,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=359a8dca6ba543c28efd4b33fba56c32&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=359a8dca6ba543c28efd4b33fba56c32&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"359a8dca6ba543c28efd4b33fba56c32"},"cover":{"url_list":["https://p9.pstatp.com/aweme/300x400/5f07001031f01c21bf41.jpeg","https://pb1.pstatp.com/aweme/300x400/5f07001031f01c21bf41.jpeg","https://pb3.pstatp.com/aweme/300x400/5f07001031f01c21bf41.jpeg"],"uri":"300x400/5f07001031f01c21bf41"},"height":1168,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=359a8dca6ba543c28efd4b33fba56c32&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=359a8dca6ba543c28efd4b33fba56c32&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"359a8dca6ba543c28efd4b33fba56c32"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5f0c000b0f939a5163c5.jpeg","http://pb9.pstatp.com/large/5f0c000b0f939a5163c5.jpeg","http://pb3.pstatp.com/large/5f0c000b0f939a5163c5.jpeg"],"uri":"large/5f0c000b0f939a5163c5"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=359a8dca6ba543c28efd4b33fba56c32&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=359a8dca6ba543c28efd4b33fba56c32&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"359a8dca6ba543c28efd4b33fba56c32"},"dynamic_cover":{"url_list":["https://p3.pstatp.com/obj/5f0f0003da4389c5a98f","https://pb9.pstatp.com/obj/5f0f0003da4389c5a98f","https://pb3.pstatp.com/obj/5f0f0003da4389c5a98f"],"uri":"5f0f0003da4389c5a98f"}},"aweme_id":"6517152788160449795","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":62711,"aweme_id":"6517152788160449795","comment_count":216,"share_count":43,"digg_count":4498},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6517152788160449795/?mid=6517152868603824909","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":true,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6517152788160449795/?region=CN&mid=6517152868603824909","share_desc":"这个结局让我无法接受...你有没有和我一样，越是重要的日子越失眠，然后...迟到、错过...你失眠的时候都干嘛"},"is_top":0,"aweme_type":0,"desc":"这个结局让我无法接受...你有没有和我一样，越是重要的日子越失眠，然后...迟到、错过...你失眠的时候都干嘛","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":76065353125,"rate":12,"create_time":1517381045,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=98aa99c7b45a4dc5ae9dad14165bc3e4&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=98aa99c7b45a4dc5ae9dad14165bc3e4&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"98aa99c7b45a4dc5ae9dad14165bc3e4"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5efe000ec6b9da7dcfa3.jpeg","https://pb9.pstatp.com/aweme/300x400/5efe000ec6b9da7dcfa3.jpeg","https://pb3.pstatp.com/aweme/300x400/5efe000ec6b9da7dcfa3.jpeg"],"uri":"300x400/5efe000ec6b9da7dcfa3"},"height":540,"width":960,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=98aa99c7b45a4dc5ae9dad14165bc3e4&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=98aa99c7b45a4dc5ae9dad14165bc3e4&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"98aa99c7b45a4dc5ae9dad14165bc3e4"},"origin_cover":{"url_list":["http://p1.pstatp.com/large/5efe000ec7615dd0a16a.jpeg","http://pb3.pstatp.com/large/5efe000ec7615dd0a16a.jpeg","http://pb3.pstatp.com/large/5efe000ec7615dd0a16a.jpeg"],"uri":"large/5efe000ec7615dd0a16a"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=98aa99c7b45a4dc5ae9dad14165bc3e4&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=98aa99c7b45a4dc5ae9dad14165bc3e4&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"98aa99c7b45a4dc5ae9dad14165bc3e4"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/5eff000de9745d0884db","https://pb3.pstatp.com/obj/5eff000de9745d0884db","https://pb3.pstatp.com/obj/5eff000de9745d0884db"],"uri":"5eff000de9745d0884db"}},"aweme_id":"6517101173009288462","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":30681,"aweme_id":"6517101173009288462","comment_count":17,"share_count":5,"digg_count":655},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6517101173009288462/?mid=6517101972473318158","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6517101173009288462/?region=CN&mid=6517101972473318158","share_desc":"作为舞蹈最棒的我，是时候展现真正的技术了，要不要一起来试试？@抖音小助手"},"is_top":0,"aweme_type":0,"desc":"作为舞蹈最棒的我，是时候展现真正的技术了，要不要一起来试试？@抖音小助手","region":"","text_extra":[{"start":30,"user_id":"6796248446","end":36,"type":0}],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":57395641826,"rate":12,"create_time":1517391961,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=d21941d1b607420cb3f9d96a3643b1b2&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=d21941d1b607420cb3f9d96a3643b1b2&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"d21941d1b607420cb3f9d96a3643b1b2"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5f09000b82a6abd1b4d7.jpeg","https://pb9.pstatp.com/aweme/300x400/5f09000b82a6abd1b4d7.jpeg","https://pb3.pstatp.com/aweme/300x400/5f09000b82a6abd1b4d7.jpeg"],"uri":"300x400/5f09000b82a6abd1b4d7"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=d21941d1b607420cb3f9d96a3643b1b2&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=d21941d1b607420cb3f9d96a3643b1b2&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"d21941d1b607420cb3f9d96a3643b1b2"},"origin_cover":{"url_list":["http://p1.pstatp.com/large/5f0a000940a2ee9daf99.jpeg","http://pb3.pstatp.com/large/5f0a000940a2ee9daf99.jpeg","http://pb3.pstatp.com/large/5f0a000940a2ee9daf99.jpeg"],"uri":"large/5f0a000940a2ee9daf99"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=d21941d1b607420cb3f9d96a3643b1b2&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=d21941d1b607420cb3f9d96a3643b1b2&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"d21941d1b607420cb3f9d96a3643b1b2"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/5f0c0008ab8d34e3aa2a","https://pb3.pstatp.com/obj/5f0c0008ab8d34e3aa2a","https://pb3.pstatp.com/obj/5f0c0008ab8d34e3aa2a"],"uri":"5f0c0008ab8d34e3aa2a"}},"aweme_id":"6517148774475762958","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":40121,"aweme_id":"6517148774475762958","comment_count":6,"share_count":9,"digg_count":427},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6517148774475762958/?mid=6507013908925483789","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6517148774475762958/?region=CN&mid=6507013908925483789","share_desc":"一群戏精，像我这样你会吗？会的话，拍个视频艾特我吧～@抖音小助手"},"is_top":0,"aweme_type":0,"desc":"一群戏精，像我这样你会吗？会的话，拍个视频艾特我吧～@抖音小助手","region":"","text_extra":[{"start":26,"user_id":"6796248446","end":32,"type":0}],"user_digged":0}],"desc":"热门挑战"},{"challenge_info":{"schema":"aweme://aweme/challenge/detail?cid=1590806730191875","user_count":3759,"author":{},"cha_name":"什么BGM我都能唱😏","cid":"1590806730191875","type":0,"desc":"一定有那么一些BGM，洗脑程度一级，你耳熟能详，听到开头就能完整地哼出来，那么如果给这些BGM配上歌词呢？你还能准确分辨是什么BGM吗？\n快来试试吧，当洗脑BGM配上魔性的歌词，看看是不是还能被一下猜出来呢~"},"aweme_list":[{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":52464993381,"rate":12,"create_time":1517275700,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=3e52b724e5884732a67123fe1ee28684&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=3e52b724e5884732a67123fe1ee28684&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"3e52b724e5884732a67123fe1ee28684"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5ec0000d5613b1c0ea55.jpeg","https://pb9.pstatp.com/aweme/300x400/5ec0000d5613b1c0ea55.jpeg","https://pb3.pstatp.com/aweme/300x400/5ec0000d5613b1c0ea55.jpeg"],"uri":"300x400/5ec0000d5613b1c0ea55"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=3e52b724e5884732a67123fe1ee28684&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=3e52b724e5884732a67123fe1ee28684&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"3e52b724e5884732a67123fe1ee28684"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5ec3000225c53a40c0e1.jpeg","http://pb9.pstatp.com/large/5ec3000225c53a40c0e1.jpeg","http://pb3.pstatp.com/large/5ec3000225c53a40c0e1.jpeg"],"uri":"large/5ec3000225c53a40c0e1"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=3e52b724e5884732a67123fe1ee28684&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=3e52b724e5884732a67123fe1ee28684&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"3e52b724e5884732a67123fe1ee28684"},"dynamic_cover":{"url_list":["https://p3.pstatp.com/obj/5ebe00162bb3884b2d71","https://pb9.pstatp.com/obj/5ebe00162bb3884b2d71","https://pb3.pstatp.com/obj/5ebe00162bb3884b2d71"],"uri":"5ebe00162bb3884b2d71"}},"aweme_id":"6516649461274381581","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":8043814,"aweme_id":"6516649461274381581","comment_count":6313,"share_count":8393,"digg_count":362631},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6516649461274381581/?mid=6516546397553527556","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6516649461274381581/?region=CN&mid=6516546397553527556","share_desc":"我就是个天才，这首歌唱的我很满意！作词.演唱：王贝宁，欢迎大家来采用BGM🙋🏻脑中有没有闪现女嘉宾出场😂"},"is_top":0,"aweme_type":0,"desc":"我就是个天才，这首歌唱的我很满意！作词.演唱：王贝宁，欢迎大家来采用BGM🙋🏻脑中有没有闪现女嘉宾出场😂","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":56626230718,"rate":12,"create_time":1517241629,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=e5010cc26abf4414a2b47576c4918791&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=e5010cc26abf4414a2b47576c4918791&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"e5010cc26abf4414a2b47576c4918791"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5eb9000667e172c6368d.jpeg","https://pb9.pstatp.com/aweme/300x400/5eb9000667e172c6368d.jpeg","https://pb3.pstatp.com/aweme/300x400/5eb9000667e172c6368d.jpeg"],"uri":"300x400/5eb9000667e172c6368d"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=e5010cc26abf4414a2b47576c4918791&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=e5010cc26abf4414a2b47576c4918791&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"e5010cc26abf4414a2b47576c4918791"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5eb30013978a5a0baf0d.jpeg","http://pb9.pstatp.com/large/5eb30013978a5a0baf0d.jpeg","http://pb3.pstatp.com/large/5eb30013978a5a0baf0d.jpeg"],"uri":"large/5eb30013978a5a0baf0d"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=e5010cc26abf4414a2b47576c4918791&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=e5010cc26abf4414a2b47576c4918791&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"e5010cc26abf4414a2b47576c4918791"},"dynamic_cover":{"url_list":["https://p3.pstatp.com/obj/5eb6000eab06209c112c","https://pb9.pstatp.com/obj/5eb6000eab06209c112c","https://pb3.pstatp.com/obj/5eb6000eab06209c112c"],"uri":"5eb6000eab06209c112c"}},"aweme_id":"6516503160662527245","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":546700,"aweme_id":"6516503160662527245","comment_count":1252,"share_count":344,"digg_count":17465},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6516503160662527245/?mid=6516503194204539651","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6516503160662527245/?region=CN&mid=6516503194204539651","share_desc":"这是什么歌曲的旋律来的？有人知道吗！哈哈哈哈～"},"is_top":0,"aweme_type":0,"desc":"这是什么歌曲的旋律来的？有人知道吗！哈哈哈哈～","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":58605725516,"rate":12,"create_time":1517206380,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=f5b377cd187f4e1dae69a91c0284e9cd&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=f5b377cd187f4e1dae69a91c0284e9cd&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"f5b377cd187f4e1dae69a91c0284e9cd"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5e9f00036c77caa2037d.jpeg","https://pb9.pstatp.com/aweme/300x400/5e9f00036c77caa2037d.jpeg","https://pb3.pstatp.com/aweme/300x400/5e9f00036c77caa2037d.jpeg"],"uri":"300x400/5e9f00036c77caa2037d"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=f5b377cd187f4e1dae69a91c0284e9cd&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=f5b377cd187f4e1dae69a91c0284e9cd&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"f5b377cd187f4e1dae69a91c0284e9cd"},"origin_cover":{"url_list":["http://p1.pstatp.com/large/5ea20000832c1a3069b6.jpeg","http://pb3.pstatp.com/large/5ea20000832c1a3069b6.jpeg","http://pb3.pstatp.com/large/5ea20000832c1a3069b6.jpeg"],"uri":"large/5ea20000832c1a3069b6"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=f5b377cd187f4e1dae69a91c0284e9cd&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=f5b377cd187f4e1dae69a91c0284e9cd&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"f5b377cd187f4e1dae69a91c0284e9cd"},"dynamic_cover":{"url_list":["https://p3.pstatp.com/obj/5ea10000fffda8270d06","https://pb9.pstatp.com/obj/5ea10000fffda8270d06","https://pb3.pstatp.com/obj/5ea10000fffda8270d06"],"uri":"5ea10000fffda8270d06"}},"aweme_id":"6516351644714667268","video_labels":[],"is_vr":false,"vr_type":0,"statistics":{"play_count":350064,"aweme_id":"6516351644714667268","comment_count":269,"share_count":90,"digg_count":3300},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6516351644714667268/?mid=6516351786834627336","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6516351644714667268/?region=CN&mid=6516351786834627336","share_desc":"啊有毒，我忘了原唱咋唱了@我是你们的一休哥哥"},"is_top":0,"aweme_type":0,"desc":"啊有毒，我忘了原唱咋唱了@我是你们的一休哥哥","region":"","text_extra":[{"at_user_type":"follow","user_id":"59421549383","start":12,"isAddPosition":false,"end":22,"type":0}],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":57422400409,"rate":12,"create_time":1517310511,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=a526e6404cc74c9287dea55eb7f2af0a&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=a526e6404cc74c9287dea55eb7f2af0a&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"a526e6404cc74c9287dea55eb7f2af0a"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5ee100010d851f485091.jpeg","https://pb9.pstatp.com/aweme/300x400/5ee100010d851f485091.jpeg","https://pb3.pstatp.com/aweme/300x400/5ee100010d851f485091.jpeg"],"uri":"300x400/5ee100010d851f485091"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=a526e6404cc74c9287dea55eb7f2af0a&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=a526e6404cc74c9287dea55eb7f2af0a&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"a526e6404cc74c9287dea55eb7f2af0a"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5edd00068302557ff21f.jpeg","http://pb9.pstatp.com/large/5edd00068302557ff21f.jpeg","http://pb3.pstatp.com/large/5edd00068302557ff21f.jpeg"],"uri":"large/5edd00068302557ff21f"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=a526e6404cc74c9287dea55eb7f2af0a&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=a526e6404cc74c9287dea55eb7f2af0a&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"a526e6404cc74c9287dea55eb7f2af0a"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/5edc000f2b9c00a404ce","https://pb3.pstatp.com/obj/5edc000f2b9c00a404ce","https://pb3.pstatp.com/obj/5edc000f2b9c00a404ce"],"uri":"5edc000f2b9c00a404ce"}},"aweme_id":"6516798999092006152","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":64786,"aweme_id":"6516798999092006152","comment_count":191,"share_count":52,"digg_count":1926},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6516798999092006152/?mid=6516799059360779022","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6516798999092006152/?region=CN&mid=6516799059360779022","share_desc":"我觉得这是病变被我黑的最狠的一次了，后面大哥在看抖音，别胡想😂"},"is_top":0,"aweme_type":0,"desc":"我觉得这是病变被我黑的最狠的一次了，后面大哥在看抖音，别胡想😂","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":61523211043,"rate":0,"create_time":1517307461,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=24f6d8ed553340808b48baf2867687db&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=24f6d8ed553340808b48baf2867687db&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"24f6d8ed553340808b48baf2867687db"},"cover":{"url_list":["https://p1.pstatp.com/aweme/300x400/5ed9000f8aefeb8d12c4.jpeg","https://pb3.pstatp.com/aweme/300x400/5ed9000f8aefeb8d12c4.jpeg","https://pb3.pstatp.com/aweme/300x400/5ed9000f8aefeb8d12c4.jpeg"],"uri":"300x400/5ed9000f8aefeb8d12c4"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=24f6d8ed553340808b48baf2867687db&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=24f6d8ed553340808b48baf2867687db&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"24f6d8ed553340808b48baf2867687db"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5ed8001201f99920267d.jpeg","http://pb9.pstatp.com/large/5ed8001201f99920267d.jpeg","http://pb3.pstatp.com/large/5ed8001201f99920267d.jpeg"],"uri":"large/5ed8001201f99920267d"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=24f6d8ed553340808b48baf2867687db&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=24f6d8ed553340808b48baf2867687db&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"24f6d8ed553340808b48baf2867687db"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/5ed60014083dc7fa40b0","https://pb3.pstatp.com/obj/5ed60014083dc7fa40b0","https://pb3.pstatp.com/obj/5ed60014083dc7fa40b0"],"uri":"5ed60014083dc7fa40b0"}},"aweme_id":"6516785887156636935","video_labels":[{"label_type":3,"label_url":{"url_list":["https://p1.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7"],"uri":"330a000f6d4569feb2f7"}}],"is_vr":false,"vr_type":1,"statistics":{"play_count":2647703,"aweme_id":"6516785887156636935","comment_count":3384,"share_count":1322,"digg_count":140504},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6516785887156636935/?mid=6486443715296758542","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p1.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7"],"uri":"330a000f6d4569feb2f7"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6516785887156636935/?region=CN&mid=6486443715296758542","share_desc":"其实我的手有根线在操控着手机😏"},"is_top":0,"label_thumb":{"url_list":["https://p1.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2"],"uri":"2efe004a4a7dc47b3bc2"},"aweme_type":0,"desc":"其实我的手有根线在操控着手机😏","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":59698927636,"rate":12,"create_time":1517310121,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=bdde5ac897bf408f939c271e49c195e1&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=bdde5ac897bf408f939c271e49c195e1&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"bdde5ac897bf408f939c271e49c195e1"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5edc000e341b292d9898.jpeg","https://pb9.pstatp.com/aweme/300x400/5edc000e341b292d9898.jpeg","https://pb3.pstatp.com/aweme/300x400/5edc000e341b292d9898.jpeg"],"uri":"300x400/5edc000e341b292d9898"},"height":1168,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=bdde5ac897bf408f939c271e49c195e1&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=bdde5ac897bf408f939c271e49c195e1&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"bdde5ac897bf408f939c271e49c195e1"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5ede0003af61b0b8ca13.jpeg","http://pb9.pstatp.com/large/5ede0003af61b0b8ca13.jpeg","http://pb3.pstatp.com/large/5ede0003af61b0b8ca13.jpeg"],"uri":"large/5ede0003af61b0b8ca13"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=bdde5ac897bf408f939c271e49c195e1&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=bdde5ac897bf408f939c271e49c195e1&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"bdde5ac897bf408f939c271e49c195e1"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/5edc000e34f4da4bcd8b","https://pb3.pstatp.com/obj/5edc000e34f4da4bcd8b","https://pb3.pstatp.com/obj/5edc000e34f4da4bcd8b"],"uri":"5edc000e34f4da4bcd8b"}},"aweme_id":"6516797179858783496","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":1464236,"aweme_id":"6516797179858783496","comment_count":742,"share_count":1783,"digg_count":123192},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6516797179858783496/?mid=6516797373006646029","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6516797179858783496/?region=CN&mid=6516797373006646029","share_desc":"哈哈哈哈 整人大王又来了@许晓晨Stephanie🍒 @MAX小霸王🔓 @楚軒-Shane-"},"is_top":0,"aweme_type":0,"desc":"哈哈哈哈 整人大王又来了@许晓晨Stephanie🍒 @MAX小霸王🔓 @楚軒-Shane-","region":"","text_extra":[{"start":12,"user_id":"62006079384","end":27,"type":0},{"start":28,"user_id":"54831232798","end":37,"type":0},{"start":38,"user_id":"57081537544","end":48,"type":0}],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":58325035431,"rate":0,"create_time":1517371318,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=a29d23663c0f49e19c93c6f8cd1dc11f&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=a29d23663c0f49e19c93c6f8cd1dc11f&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"a29d23663c0f49e19c93c6f8cd1dc11f"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5ef70000bad68008b7a0.jpeg","https://pb9.pstatp.com/aweme/300x400/5ef70000bad68008b7a0.jpeg","https://pb3.pstatp.com/aweme/300x400/5ef70000bad68008b7a0.jpeg"],"uri":"300x400/5ef70000bad68008b7a0"},"height":1168,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=a29d23663c0f49e19c93c6f8cd1dc11f&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=a29d23663c0f49e19c93c6f8cd1dc11f&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"a29d23663c0f49e19c93c6f8cd1dc11f"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5ef70000bb518ea78a7b.jpeg","http://pb9.pstatp.com/large/5ef70000bb518ea78a7b.jpeg","http://pb3.pstatp.com/large/5ef70000bb518ea78a7b.jpeg"],"uri":"large/5ef70000bb518ea78a7b"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=a29d23663c0f49e19c93c6f8cd1dc11f&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=a29d23663c0f49e19c93c6f8cd1dc11f&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"a29d23663c0f49e19c93c6f8cd1dc11f"},"dynamic_cover":{"url_list":["https://p9.pstatp.com/obj/5ef00011320a0572e1db","https://pb1.pstatp.com/obj/5ef00011320a0572e1db","https://pb3.pstatp.com/obj/5ef00011320a0572e1db"],"uri":"5ef00011320a0572e1db"}},"aweme_id":"6517060079873690887","video_labels":[{"label_type":3,"label_url":{"url_list":["https://p1.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7"],"uri":"330a000f6d4569feb2f7"}}],"is_vr":false,"vr_type":1,"statistics":{"play_count":2079906,"aweme_id":"6517060079873690887","comment_count":2902,"share_count":530,"digg_count":118302},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6517060079873690887/?mid=6514522910366010125","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p1.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7"],"uri":"330a000f6d4569feb2f7"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6517060079873690887/?region=CN&mid=6514522910366010125","share_desc":"我花了一早上终于和我妈排练好了哈哈哈哈😂"},"is_top":0,"label_thumb":{"url_list":["https://p1.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2"],"uri":"2efe004a4a7dc47b3bc2"},"aweme_type":0,"desc":"我花了一早上终于和我妈排练好了哈哈哈哈😂","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":54831232798,"rate":12,"create_time":1517310892,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=448fa566fa3b41069776f72f7178d421&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=448fa566fa3b41069776f72f7178d421&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"448fa566fa3b41069776f72f7178d421"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5ede00059b54a7a78b1c.jpeg","https://pb9.pstatp.com/aweme/300x400/5ede00059b54a7a78b1c.jpeg","https://pb3.pstatp.com/aweme/300x400/5ede00059b54a7a78b1c.jpeg"],"uri":"300x400/5ede00059b54a7a78b1c"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=448fa566fa3b41069776f72f7178d421&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=448fa566fa3b41069776f72f7178d421&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"448fa566fa3b41069776f72f7178d421"},"origin_cover":{"url_list":["http://p1.pstatp.com/large/5edd000778796c3366d1.jpeg","http://pb3.pstatp.com/large/5edd000778796c3366d1.jpeg","http://pb3.pstatp.com/large/5edd000778796c3366d1.jpeg"],"uri":"large/5edd000778796c3366d1"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=448fa566fa3b41069776f72f7178d421&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=448fa566fa3b41069776f72f7178d421&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"448fa566fa3b41069776f72f7178d421"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/5ede00059c25099de141","https://pb3.pstatp.com/obj/5ede00059c25099de141","https://pb3.pstatp.com/obj/5ede00059c25099de141"],"uri":"5ede00059c25099de141"}},"aweme_id":"6516800629095009550","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":2450777,"aweme_id":"6516800629095009550","comment_count":1240,"share_count":4094,"digg_count":111146},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6516800629095009550/?mid=6516800660515195661","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6516800629095009550/?region=CN&mid=6516800660515195661","share_desc":"小霸王式表白😎哈哈哈哈哈感动不😹"},"is_top":0,"aweme_type":0,"desc":"小霸王式表白😎哈哈哈哈哈感动不😹","region":"","text_extra":[],"user_digged":0}],"desc":"热门挑战"},{"challenge_info":{"schema":"aweme://aweme/challenge/detail?cid=1590626702581767","user_count":7993,"author":{},"cha_name":"我的画张\u201c嘴\u201d唱歌了！","cid":"1590626702581767","type":0,"desc":"用你天马行空的创意，制作一张水果、动物、表情包等类型的折叠画，将折叠处想象成一张\u201c嘴\u201d，并配上魔性的背景音乐或者用自己的原声哼唱，将纸张交替折叠与舒展，这样你的折叠画就可以张\u201c嘴\u201d唱歌了！大开脑洞，玩转创意的时候到了，快来展示你的折叠画吧！\n"},"aweme_list":[{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":65100609659,"rate":12,"create_time":1517130870,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=b38e436ebc5a4e9f8d83dd498df01136&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=b38e436ebc5a4e9f8d83dd498df01136&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"b38e436ebc5a4e9f8d83dd498df01136"},"cover":{"url_list":["https://p1.pstatp.com/aweme/300x400/5cbb0006aea1ff95ea79.jpeg","https://pb3.pstatp.com/aweme/300x400/5cbb0006aea1ff95ea79.jpeg","https://pb3.pstatp.com/aweme/300x400/5cbb0006aea1ff95ea79.jpeg"],"uri":"300x400/5cbb0006aea1ff95ea79"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=b38e436ebc5a4e9f8d83dd498df01136&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=b38e436ebc5a4e9f8d83dd498df01136&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"b38e436ebc5a4e9f8d83dd498df01136"},"origin_cover":{"url_list":["http://p1.pstatp.com/large/5cb90009a3673506f487.jpeg","http://pb3.pstatp.com/large/5cb90009a3673506f487.jpeg","http://pb3.pstatp.com/large/5cb90009a3673506f487.jpeg"],"uri":"large/5cb90009a3673506f487"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=b38e436ebc5a4e9f8d83dd498df01136&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=b38e436ebc5a4e9f8d83dd498df01136&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"b38e436ebc5a4e9f8d83dd498df01136"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/5cb80009bfce17516871","https://pb3.pstatp.com/obj/5cb80009bfce17516871","https://pb3.pstatp.com/obj/5cb80009bfce17516871"],"uri":"5cb80009bfce17516871"}},"aweme_id":"6516027422196894990","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":450756,"aweme_id":"6516027422196894990","comment_count":150,"share_count":183,"digg_count":8559},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6516027422196894990/?mid=6318975470264126210","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6516027422196894990/?region=CN&mid=6318975470264126210","share_desc":"这次我就不出镜了，派出我的三个小兄弟为大家带来好汉歌💪这么冷的天没事别出门了，在家看抖音吧，哈哈哈哈❄️"},"is_top":0,"aweme_type":0,"desc":"这次我就不出镜了，派出我的三个小兄弟为大家带来好汉歌💪这么冷的天没事别出门了，在家看抖音吧，哈哈哈哈❄️","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":73672799237,"rate":12,"create_time":1517224360,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=a6f8f8a61f0a4ead8fc7656fd8db295f&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=a6f8f8a61f0a4ead8fc7656fd8db295f&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"a6f8f8a61f0a4ead8fc7656fd8db295f"},"cover":{"url_list":["https://p1.pstatp.com/aweme/300x400/5eae00069820eaa2f506.jpeg","https://pb3.pstatp.com/aweme/300x400/5eae00069820eaa2f506.jpeg","https://pb3.pstatp.com/aweme/300x400/5eae00069820eaa2f506.jpeg"],"uri":"300x400/5eae00069820eaa2f506"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=a6f8f8a61f0a4ead8fc7656fd8db295f&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=a6f8f8a61f0a4ead8fc7656fd8db295f&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"a6f8f8a61f0a4ead8fc7656fd8db295f"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5ead0006bf0f4b7ccfe7.jpeg","http://pb9.pstatp.com/large/5ead0006bf0f4b7ccfe7.jpeg","http://pb3.pstatp.com/large/5ead0006bf0f4b7ccfe7.jpeg"],"uri":"large/5ead0006bf0f4b7ccfe7"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=a6f8f8a61f0a4ead8fc7656fd8db295f&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=a6f8f8a61f0a4ead8fc7656fd8db295f&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"a6f8f8a61f0a4ead8fc7656fd8db295f"},"dynamic_cover":{"url_list":["https://p3.pstatp.com/obj/5eaa0011f747e8c9a518","https://pb9.pstatp.com/obj/5eaa0011f747e8c9a518","https://pb3.pstatp.com/obj/5eaa0011f747e8c9a518"],"uri":"5eaa0011f747e8c9a518"}},"aweme_id":"6516428958538403085","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":115656,"aweme_id":"6516428958538403085","comment_count":61,"share_count":126,"digg_count":2831},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6516428958538403085/?mid=6475233507957771022","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6516428958538403085/?region=CN&mid=6475233507957771022","share_desc":"oh！no！全聚德！腿软！@抖音小助手"},"is_top":0,"aweme_type":0,"desc":"oh！no！全聚德！腿软！@抖音小助手","region":"","text_extra":[{"start":13,"user_id":"6796248446","end":19,"type":0}],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":52348510570,"rate":12,"create_time":1517280327,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=21f1e4b9f3354c018dee865a3c5cb85f&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=21f1e4b9f3354c018dee865a3c5cb85f&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"21f1e4b9f3354c018dee865a3c5cb85f"},"cover":{"url_list":["https://p9.pstatp.com/aweme/300x400/5ec1000e08a915f8e2ec.jpeg","https://pb1.pstatp.com/aweme/300x400/5ec1000e08a915f8e2ec.jpeg","https://pb3.pstatp.com/aweme/300x400/5ec1000e08a915f8e2ec.jpeg"],"uri":"300x400/5ec1000e08a915f8e2ec"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=21f1e4b9f3354c018dee865a3c5cb85f&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=21f1e4b9f3354c018dee865a3c5cb85f&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"21f1e4b9f3354c018dee865a3c5cb85f"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5ec2000c2b7a64b0720c.jpeg","http://pb9.pstatp.com/large/5ec2000c2b7a64b0720c.jpeg","http://pb3.pstatp.com/large/5ec2000c2b7a64b0720c.jpeg"],"uri":"large/5ec2000c2b7a64b0720c"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=21f1e4b9f3354c018dee865a3c5cb85f&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=21f1e4b9f3354c018dee865a3c5cb85f&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"21f1e4b9f3354c018dee865a3c5cb85f"},"dynamic_cover":{"url_list":["https://p3.pstatp.com/obj/5ec3000bfe7a6813bb75","https://pb9.pstatp.com/obj/5ec3000bfe7a6813bb75","https://pb3.pstatp.com/obj/5ec3000bfe7a6813bb75"],"uri":"5ec3000bfe7a6813bb75"}},"aweme_id":"6516668804771089667","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":149385,"aweme_id":"6516668804771089667","comment_count":57,"share_count":58,"digg_count":2820},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6516668804771089667/?mid=6318975470264126210","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":true,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6516668804771089667/?region=CN&mid=6318975470264126210","share_desc":"一早上花了好多次，拍了好多遍，哈哈哈，看我抖动神功，鲁智深是不是神似哈哈哈。看完别忘了给❤啊"},"is_top":0,"aweme_type":0,"desc":"一早上花了好多次，拍了好多遍，哈哈哈，看我抖动神功，鲁智深是不是神似哈哈哈。看完别忘了给❤啊","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":57506180696,"rate":10,"create_time":1517227435,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=b3bcd636d0b442c9b7ecfae779751985&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=b3bcd636d0b442c9b7ecfae779751985&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"b3bcd636d0b442c9b7ecfae779751985"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5eb200036c96d3e2c270.jpeg","https://pb9.pstatp.com/aweme/300x400/5eb200036c96d3e2c270.jpeg","https://pb3.pstatp.com/aweme/300x400/5eb200036c96d3e2c270.jpeg"],"uri":"300x400/5eb200036c96d3e2c270"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=b3bcd636d0b442c9b7ecfae779751985&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=b3bcd636d0b442c9b7ecfae779751985&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"b3bcd636d0b442c9b7ecfae779751985"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5eac0010c94d6440d5e9.jpeg","http://pb9.pstatp.com/large/5eac0010c94d6440d5e9.jpeg","http://pb3.pstatp.com/large/5eac0010c94d6440d5e9.jpeg"],"uri":"large/5eac0010c94d6440d5e9"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=b3bcd636d0b442c9b7ecfae779751985&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=b3bcd636d0b442c9b7ecfae779751985&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"b3bcd636d0b442c9b7ecfae779751985"},"dynamic_cover":{"url_list":["https://p3.pstatp.com/obj/5eb200036d3a9728e89d","https://pb9.pstatp.com/obj/5eb200036d3a9728e89d","https://pb3.pstatp.com/obj/5eb200036d3a9728e89d"],"uri":"5eb200036d3a9728e89d"}},"aweme_id":"6516441927414451469","video_labels":[],"is_vr":false,"vr_type":0,"statistics":{"play_count":82565,"aweme_id":"6516441927414451469","comment_count":24,"share_count":26,"digg_count":1128},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6516441927414451469/?mid=6490853763822160653","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6516441927414451469/?region=CN&mid=6490853763822160653","share_desc":"我的画也会唱歌啦😄，你们用过这个表情包嘛，西迪&朵兰"},"is_top":0,"aweme_type":0,"desc":"我的画也会唱歌啦😄，你们用过这个表情包嘛，西迪&朵兰","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":61265023364,"rate":12,"create_time":1517226421,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=41009d0ef28d47269b3bbbdf72541424&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=41009d0ef28d47269b3bbbdf72541424&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"41009d0ef28d47269b3bbbdf72541424"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5eb100019410429c1cb7.jpeg","https://pb9.pstatp.com/aweme/300x400/5eb100019410429c1cb7.jpeg","https://pb3.pstatp.com/aweme/300x400/5eb100019410429c1cb7.jpeg"],"uri":"300x400/5eb100019410429c1cb7"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=41009d0ef28d47269b3bbbdf72541424&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=41009d0ef28d47269b3bbbdf72541424&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"41009d0ef28d47269b3bbbdf72541424"},"origin_cover":{"url_list":["http://p9.pstatp.com/large/5eac000e346e5920de4c.jpeg","http://pb1.pstatp.com/large/5eac000e346e5920de4c.jpeg","http://pb3.pstatp.com/large/5eac000e346e5920de4c.jpeg"],"uri":"large/5eac000e346e5920de4c"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=41009d0ef28d47269b3bbbdf72541424&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=41009d0ef28d47269b3bbbdf72541424&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"41009d0ef28d47269b3bbbdf72541424"},"dynamic_cover":{"url_list":["https://p3.pstatp.com/obj/5eb20000d98be43108c5","https://pb9.pstatp.com/obj/5eb20000d98be43108c5","https://pb3.pstatp.com/obj/5eb20000d98be43108c5"],"uri":"5eb20000d98be43108c5"}},"aweme_id":"6516437790849240323","video_labels":[],"is_vr":false,"vr_type":0,"statistics":{"play_count":62614,"aweme_id":"6516437790849240323","comment_count":28,"share_count":23,"digg_count":1140},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6516437790849240323/?mid=6324941229469469442","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6516437790849240323/?region=CN&mid=6324941229469469442","share_desc":"小黄人banana"},"is_top":0,"aweme_type":0,"desc":"小黄人banana","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":74331329551,"rate":12,"create_time":1517234048,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=470d65dbc9794bf98977fc50cc72e9d1&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=470d65dbc9794bf98977fc50cc72e9d1&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"470d65dbc9794bf98977fc50cc72e9d1"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5eb30009abd948ceb3ca.jpeg","https://pb9.pstatp.com/aweme/300x400/5eb30009abd948ceb3ca.jpeg","https://pb3.pstatp.com/aweme/300x400/5eb30009abd948ceb3ca.jpeg"],"uri":"300x400/5eb30009abd948ceb3ca"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=470d65dbc9794bf98977fc50cc72e9d1&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=470d65dbc9794bf98977fc50cc72e9d1&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"470d65dbc9794bf98977fc50cc72e9d1"},"origin_cover":{"url_list":["http://p9.pstatp.com/large/5eb50007605564f4a53a.jpeg","http://pb1.pstatp.com/large/5eb50007605564f4a53a.jpeg","http://pb3.pstatp.com/large/5eb50007605564f4a53a.jpeg"],"uri":"large/5eb50007605564f4a53a"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=470d65dbc9794bf98977fc50cc72e9d1&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=470d65dbc9794bf98977fc50cc72e9d1&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"470d65dbc9794bf98977fc50cc72e9d1"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/5eb20012b5938273cf5c","https://pb3.pstatp.com/obj/5eb20012b5938273cf5c","https://pb3.pstatp.com/obj/5eb20012b5938273cf5c"],"uri":"5eb20012b5938273cf5c"}},"aweme_id":"6516470367689641219","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":59129,"aweme_id":"6516470367689641219","comment_count":23,"share_count":21,"digg_count":1013},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6516470367689641219/?mid=6475233507957771022","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6516470367689641219/?region=CN&mid=6475233507957771022","share_desc":"跟我比\u201c剑\u201d？嗯，知道你\u201c剑\u201d！就这样\u2026\u2026❤️"},"is_top":0,"aweme_type":0,"desc":"跟我比\u201c剑\u201d？嗯，知道你\u201c剑\u201d！就这样\u2026\u2026❤️","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":55970364958,"rate":12,"create_time":1517233939,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=2bbbcb95e0ad41efa786afd741543dbe&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=2bbbcb95e0ad41efa786afd741543dbe&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"2bbbcb95e0ad41efa786afd741543dbe"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5eb5000728f902b5f21a.jpeg","https://pb9.pstatp.com/aweme/300x400/5eb5000728f902b5f21a.jpeg","https://pb3.pstatp.com/aweme/300x400/5eb5000728f902b5f21a.jpeg"],"uri":"300x400/5eb5000728f902b5f21a"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=2bbbcb95e0ad41efa786afd741543dbe&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=2bbbcb95e0ad41efa786afd741543dbe&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"2bbbcb95e0ad41efa786afd741543dbe"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5eb6000486ae1f1d60fc.jpeg","http://pb9.pstatp.com/large/5eb6000486ae1f1d60fc.jpeg","http://pb3.pstatp.com/large/5eb6000486ae1f1d60fc.jpeg"],"uri":"large/5eb6000486ae1f1d60fc"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=2bbbcb95e0ad41efa786afd741543dbe&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=2bbbcb95e0ad41efa786afd741543dbe&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"2bbbcb95e0ad41efa786afd741543dbe"},"dynamic_cover":{"url_list":["https://p9.pstatp.com/obj/5eb700041c7d99bab045","https://pb1.pstatp.com/obj/5eb700041c7d99bab045","https://pb3.pstatp.com/obj/5eb700041c7d99bab045"],"uri":"5eb700041c7d99bab045"}},"aweme_id":"6516469683053399303","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":49758,"aweme_id":"6516469683053399303","comment_count":28,"share_count":33,"digg_count":783},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6516469683053399303/?mid=6475233507957771022","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6516469683053399303/?region=CN&mid=6475233507957771022","share_desc":"哈哈，好玩，生活无处不创意！@抖音小助手 来，张开你的嘴！路过的亲点赞啦❤❤❤"},"is_top":0,"aweme_type":0,"desc":"哈哈，好玩，生活无处不创意！@抖音小助手 来，张开你的嘴！路过的亲点赞啦❤❤❤","region":"","text_extra":[{"start":14,"user_id":"6796248446","end":20,"type":0}],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":73228854665,"rate":12,"create_time":1517277092,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=96e4689bcc1b449387ffc2392d37a6e2&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=96e4689bcc1b449387ffc2392d37a6e2&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"96e4689bcc1b449387ffc2392d37a6e2"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5ec30004e806f417c1bf.jpeg","https://pb9.pstatp.com/aweme/300x400/5ec30004e806f417c1bf.jpeg","https://pb3.pstatp.com/aweme/300x400/5ec30004e806f417c1bf.jpeg"],"uri":"300x400/5ec30004e806f417c1bf"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=96e4689bcc1b449387ffc2392d37a6e2&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=96e4689bcc1b449387ffc2392d37a6e2&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"96e4689bcc1b449387ffc2392d37a6e2"},"origin_cover":{"url_list":["http://p1.pstatp.com/large/5ec20005121933e0c63e.jpeg","http://pb3.pstatp.com/large/5ec20005121933e0c63e.jpeg","http://pb3.pstatp.com/large/5ec20005121933e0c63e.jpeg"],"uri":"large/5ec20005121933e0c63e"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=96e4689bcc1b449387ffc2392d37a6e2&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=96e4689bcc1b449387ffc2392d37a6e2&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"96e4689bcc1b449387ffc2392d37a6e2"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/5ebf0010fdb2bdc82283","https://pb3.pstatp.com/obj/5ebf0010fdb2bdc82283","https://pb3.pstatp.com/obj/5ebf0010fdb2bdc82283"],"uri":"5ebf0010fdb2bdc82283"}},"aweme_id":"6516655480805264644","video_labels":[],"is_vr":false,"vr_type":0,"statistics":{"play_count":39322,"aweme_id":"6516655480805264644","comment_count":9,"share_count":10,"digg_count":547},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6516655480805264644/?mid=6475233507957771022","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6516655480805264644/?region=CN&mid=6475233507957771022","share_desc":"抖音-原创音乐短视频社区"},"is_top":0,"aweme_type":0,"desc":"","region":"","text_extra":[],"user_digged":0}],"desc":"热门挑战"},{"challenge_info":{"schema":"aweme://aweme/challenge/detail?cid=1576867134378014","user_count":51627,"author":{},"cha_name":"C哩C哩舞","cid":"1576867134378014","type":0,"desc":"C哩C哩舞最近真的不要太火，听到这个音乐，不会跳舞也能让你快速get魔性洗脑舞步~选择音乐《panama》，搭配尬舞的标配表情，解封你封印的舞魂吧~你一本正经跳舞的样子已经承包了我全部的笑点哦~"},"aweme_list":[{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":56626230718,"rate":0,"create_time":1503817894,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=d96ceef83a114decb47af00c74c86896&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=d96ceef83a114decb47af00c74c86896&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"d96ceef83a114decb47af00c74c86896"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/37860000d697ad30411a.jpeg","https://pb9.pstatp.com/aweme/300x400/37860000d697ad30411a.jpeg","https://pb3.pstatp.com/aweme/300x400/37860000d697ad30411a.jpeg"],"uri":"300x400/37860000d697ad30411a"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=d96ceef83a114decb47af00c74c86896&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=d96ceef83a114decb47af00c74c86896&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"d96ceef83a114decb47af00c74c86896"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/37860000d697ad30411a.jpeg","http://pb9.pstatp.com/large/37860000d697ad30411a.jpeg","http://pb3.pstatp.com/large/37860000d697ad30411a.jpeg"],"uri":"large/37860000d697ad30411a"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=d96ceef83a114decb47af00c74c86896&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=d96ceef83a114decb47af00c74c86896&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"d96ceef83a114decb47af00c74c86896"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/37850000d76d60466c5b","https://pb3.pstatp.com/obj/37850000d76d60466c5b","https://pb3.pstatp.com/obj/37850000d76d60466c5b"],"uri":"37850000d76d60466c5b"}},"aweme_id":"6458848585306869006","video_labels":[{"label_type":3,"label_url":{"url_list":["https://p1.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7"],"uri":"330a000f6d4569feb2f7"}}],"is_vr":false,"vr_type":0,"statistics":{"play_count":14140432,"aweme_id":"6458848585306869006","comment_count":3451,"share_count":25867,"digg_count":182455},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6458848585306869006/?mid=6396936151697263361","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p1.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7"],"uri":"330a000f6d4569feb2f7"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6458848585306869006/?region=CN&mid=6396936151697263361","share_desc":"三个人，三种风格，选一种一起C哩起来吧~@👾薛老湿 @👌心然🏋🏻♀️"},"is_top":0,"label_thumb":{"url_list":["https://p1.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2"],"uri":"2efe004a4a7dc47b3bc2"},"aweme_type":0,"desc":"三个人，三种风格，选一种一起C哩起来吧~@👾薛老湿 @👌心然🏋🏻♀️","region":"CN","text_extra":[{"start":20,"user_id":"52010093998","end":26,"type":0},{"start":27,"user_id":"57676435537","end":38,"type":0}],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":70917176469,"rate":10,"create_time":1513316250,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=7bc5afc7de1948639389111f65612180&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=7bc5afc7de1948639389111f65612180&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"7bc5afc7de1948639389111f65612180"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/4cdc0005b4dd9eec1eb0.jpeg","https://pb9.pstatp.com/aweme/300x400/4cdc0005b4dd9eec1eb0.jpeg","https://pb3.pstatp.com/aweme/300x400/4cdc0005b4dd9eec1eb0.jpeg"],"uri":"300x400/4cdc0005b4dd9eec1eb0"},"height":960,"width":544,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=7bc5afc7de1948639389111f65612180&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=7bc5afc7de1948639389111f65612180&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"7bc5afc7de1948639389111f65612180"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/4cdc0005b4dd9eec1eb0.jpeg","http://pb9.pstatp.com/large/4cdc0005b4dd9eec1eb0.jpeg","http://pb3.pstatp.com/large/4cdc0005b4dd9eec1eb0.jpeg"],"uri":"large/4cdc0005b4dd9eec1eb0"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=7bc5afc7de1948639389111f65612180&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=7bc5afc7de1948639389111f65612180&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"7bc5afc7de1948639389111f65612180"},"dynamic_cover":{"url_list":["https://p3.pstatp.com/obj/4cdc0005b5ad53ef768f","https://pb9.pstatp.com/obj/4cdc0005b5ad53ef768f","https://pb3.pstatp.com/obj/4cdc0005b5ad53ef768f"],"uri":"4cdc0005b5ad53ef768f"}},"aweme_id":"6499643516526791949","video_labels":[],"is_vr":false,"vr_type":0,"statistics":{"play_count":16856903,"aweme_id":"6499643516526791949","comment_count":11494,"share_count":31087,"digg_count":587789},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6499643516526791949/?mid=6499643810883537678","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6499643516526791949/?region=CN&mid=6499643810883537678","share_desc":"following the magic Cadence，Join the challenge"},"is_top":0,"aweme_type":0,"desc":"following the magic Cadence，Join the challenge","region":"CN","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":62665001430,"rate":11,"create_time":1506503193,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=c02077a3edda4e088b498d89487425b2&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=c02077a3edda4e088b498d89487425b2&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"c02077a3edda4e088b498d89487425b2"},"cover":{"url_list":["https://p1.pstatp.com/aweme/300x400/3c0c0008ba37ca6ed14b.jpeg","https://pb3.pstatp.com/aweme/300x400/3c0c0008ba37ca6ed14b.jpeg","https://pb3.pstatp.com/aweme/300x400/3c0c0008ba37ca6ed14b.jpeg"],"uri":"300x400/3c0c0008ba37ca6ed14b"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=c02077a3edda4e088b498d89487425b2&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=c02077a3edda4e088b498d89487425b2&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"c02077a3edda4e088b498d89487425b2"},"origin_cover":{"url_list":["http://p1.pstatp.com/large/3c0c0008ba37ca6ed14b.jpeg","http://pb3.pstatp.com/large/3c0c0008ba37ca6ed14b.jpeg","http://pb3.pstatp.com/large/3c0c0008ba37ca6ed14b.jpeg"],"uri":"large/3c0c0008ba37ca6ed14b"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=c02077a3edda4e088b498d89487425b2&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=c02077a3edda4e088b498d89487425b2&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"c02077a3edda4e088b498d89487425b2"},"dynamic_cover":{"url_list":["https://p3.pstatp.com/obj/3c0a000e475fe3f92cb3","https://pb9.pstatp.com/obj/3c0a000e475fe3f92cb3","https://pb3.pstatp.com/obj/3c0a000e475fe3f92cb3"],"uri":"3c0a000e475fe3f92cb3"}},"aweme_id":"6470381826006322445","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":28004781,"aweme_id":"6470381826006322445","comment_count":30769,"share_count":193678,"digg_count":848434},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6470381826006322445/?mid=6487801730955873038","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6470381826006322445/?region=CN&mid=6487801730955873038","share_desc":"抖音-原创音乐短视频社区"},"is_top":0,"aweme_type":0,"desc":"","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":59189023286,"rate":12,"create_time":1505994433,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=7a259039d06240308a9e90858d13ccb0&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=7a259039d06240308a9e90858d13ccb0&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"7a259039d06240308a9e90858d13ccb0"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/3aea000ab711931ed13b.jpeg","https://pb9.pstatp.com/aweme/300x400/3aea000ab711931ed13b.jpeg","https://pb3.pstatp.com/aweme/300x400/3aea000ab711931ed13b.jpeg"],"uri":"300x400/3aea000ab711931ed13b"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=7a259039d06240308a9e90858d13ccb0&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=7a259039d06240308a9e90858d13ccb0&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"7a259039d06240308a9e90858d13ccb0"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/3aea000ab711931ed13b.jpeg","http://pb9.pstatp.com/large/3aea000ab711931ed13b.jpeg","http://pb3.pstatp.com/large/3aea000ab711931ed13b.jpeg"],"uri":"large/3aea000ab711931ed13b"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=7a259039d06240308a9e90858d13ccb0&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=7a259039d06240308a9e90858d13ccb0&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"7a259039d06240308a9e90858d13ccb0"},"dynamic_cover":{"url_list":["https://p9.pstatp.com/obj/3ae9000abb6c43a1245f","https://pb1.pstatp.com/obj/3ae9000abb6c43a1245f","https://pb3.pstatp.com/obj/3ae9000abb6c43a1245f"],"uri":"3ae9000abb6c43a1245f"}},"aweme_id":"6468196804377709838","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":23959924,"aweme_id":"6468196804377709838","comment_count":10815,"share_count":104114,"digg_count":681763},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6468196804377709838/?mid=6487803031881517838","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6468196804377709838/?region=CN&mid=6487803031881517838","share_desc":"哈哈哈哈，这是C叔叔跳过最复杂的舞了......."},"is_top":0,"aweme_type":0,"desc":"哈哈哈哈，这是C叔叔跳过最复杂的舞了.......","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":58790029249,"rate":0,"create_time":1506333878,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=6cf63b941321439c91505cfb14ccaba3&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=6cf63b941321439c91505cfb14ccaba3&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"6cf63b941321439c91505cfb14ccaba3"},"cover":{"url_list":["https://p1.pstatp.com/aweme/300x400/3bd7000734417c93a66f.jpeg","https://pb3.pstatp.com/aweme/300x400/3bd7000734417c93a66f.jpeg","https://pb3.pstatp.com/aweme/300x400/3bd7000734417c93a66f.jpeg"],"uri":"300x400/3bd7000734417c93a66f"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=6cf63b941321439c91505cfb14ccaba3&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=6cf63b941321439c91505cfb14ccaba3&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"6cf63b941321439c91505cfb14ccaba3"},"origin_cover":{"url_list":["http://p1.pstatp.com/large/3bd7000734417c93a66f.jpeg","http://pb3.pstatp.com/large/3bd7000734417c93a66f.jpeg","http://pb3.pstatp.com/large/3bd7000734417c93a66f.jpeg"],"uri":"large/3bd7000734417c93a66f"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=6cf63b941321439c91505cfb14ccaba3&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=6cf63b941321439c91505cfb14ccaba3&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"6cf63b941321439c91505cfb14ccaba3"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/3bd60008ab8bd30a59ba","https://pb3.pstatp.com/obj/3bd60008ab8bd30a59ba","https://pb3.pstatp.com/obj/3bd60008ab8bd30a59ba"],"uri":"3bd60008ab8bd30a59ba"}},"aweme_id":"6469654608833678606","video_labels":[{"label_type":3,"label_url":{"url_list":["https://p1.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7"],"uri":"330a000f6d4569feb2f7"}}],"is_vr":false,"vr_type":0,"statistics":{"play_count":16987464,"aweme_id":"6469654608833678606","comment_count":3572,"share_count":44866,"digg_count":458801},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6469654608833678606/?mid=6396936151697263361","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p1.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7"],"uri":"330a000f6d4569feb2f7"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6469654608833678606/?region=CN&mid=6396936151697263361","share_desc":"全网最火C哩C哩 完整版哦～"},"is_top":0,"label_thumb":{"url_list":["https://p1.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2"],"uri":"2efe004a4a7dc47b3bc2"},"aweme_type":0,"desc":"全网最火C哩C哩 完整版哦～","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":61988925625,"rate":0,"create_time":1505203623,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=fe323121de594c4eba88671502c62c74&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=fe323121de594c4eba88671502c62c74&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"fe323121de594c4eba88671502c62c74"},"cover":{"url_list":["https://p1.pstatp.com/aweme/300x400/39820005722911a20164.jpeg","https://pb3.pstatp.com/aweme/300x400/39820005722911a20164.jpeg","https://pb3.pstatp.com/aweme/300x400/39820005722911a20164.jpeg"],"uri":"300x400/39820005722911a20164"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=fe323121de594c4eba88671502c62c74&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=fe323121de594c4eba88671502c62c74&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"fe323121de594c4eba88671502c62c74"},"origin_cover":{"url_list":["http://p1.pstatp.com/large/39820005722911a20164.jpeg","http://pb3.pstatp.com/large/39820005722911a20164.jpeg","http://pb3.pstatp.com/large/39820005722911a20164.jpeg"],"uri":"large/39820005722911a20164"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=fe323121de594c4eba88671502c62c74&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=fe323121de594c4eba88671502c62c74&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"fe323121de594c4eba88671502c62c74"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/397e000c537758c8ab7a","https://pb3.pstatp.com/obj/397e000c537758c8ab7a","https://pb3.pstatp.com/obj/397e000c537758c8ab7a"],"uri":"397e000c537758c8ab7a"}},"aweme_id":"6464800282734759182","video_labels":[{"label_type":3,"label_url":{"url_list":["https://p1.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7"],"uri":"330a000f6d4569feb2f7"}}],"is_vr":false,"vr_type":1,"statistics":{"play_count":17804396,"aweme_id":"6464800282734759182","comment_count":3408,"share_count":41758,"digg_count":438104},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6464800282734759182/?mid=6487806303883561742","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p1.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7"],"uri":"330a000f6d4569feb2f7"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6464800282734759182/?region=CN&mid=6487806303883561742","share_desc":"点赞吧！支持我"},"is_top":0,"label_thumb":{"url_list":["https://p1.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2"],"uri":"2efe004a4a7dc47b3bc2"},"aweme_type":0,"desc":"点赞吧！支持我","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":58011014629,"rate":0,"create_time":1504193276,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=859f27b19ee54a09a0613809c7b775b6&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=859f27b19ee54a09a0613809c7b775b6&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"859f27b19ee54a09a0613809c7b775b6"},"cover":{"url_list":["https://p1.pstatp.com/aweme/300x400/38690011f04964ea97d9.jpeg","https://pb3.pstatp.com/aweme/300x400/38690011f04964ea97d9.jpeg","https://pb3.pstatp.com/aweme/300x400/38690011f04964ea97d9.jpeg"],"uri":"300x400/38690011f04964ea97d9"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=859f27b19ee54a09a0613809c7b775b6&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=859f27b19ee54a09a0613809c7b775b6&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"859f27b19ee54a09a0613809c7b775b6"},"origin_cover":{"url_list":["http://p1.pstatp.com/large/38690011f04964ea97d9.jpeg","http://pb3.pstatp.com/large/38690011f04964ea97d9.jpeg","http://pb3.pstatp.com/large/38690011f04964ea97d9.jpeg"],"uri":"large/38690011f04964ea97d9"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=859f27b19ee54a09a0613809c7b775b6&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=859f27b19ee54a09a0613809c7b775b6&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"859f27b19ee54a09a0613809c7b775b6"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/386d000121eb8bf8b5a0","https://pb3.pstatp.com/obj/386d000121eb8bf8b5a0","https://pb3.pstatp.com/obj/386d000121eb8bf8b5a0"],"uri":"386d000121eb8bf8b5a0"}},"aweme_id":"6460460818759683342","video_labels":[{"label_type":3,"label_url":{"url_list":["https://p1.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7"],"uri":"330a000f6d4569feb2f7"}}],"is_vr":false,"vr_type":0,"statistics":{"play_count":14992910,"aweme_id":"6460460818759683342","comment_count":13290,"share_count":74753,"digg_count":428243},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6460460818759683342/?mid=6396936151697263361","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p1.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7"],"uri":"330a000f6d4569feb2f7"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6460460818759683342/?region=CN&mid=6396936151697263361","share_desc":"这个歌好像很火😂😂"},"is_top":0,"label_thumb":{"url_list":["https://p1.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2"],"uri":"2efe004a4a7dc47b3bc2"},"aweme_type":0,"desc":"这个歌好像很火😂😂","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":64683013580,"rate":0,"create_time":1504447479,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=dba4c949fe724414b9455dcfb0ecdd20&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=dba4c949fe724414b9455dcfb0ecdd20&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"dba4c949fe724414b9455dcfb0ecdd20"},"cover":{"url_list":["https://p9.pstatp.com/aweme/300x400/38a70000fdc960875a10.jpeg","https://pb1.pstatp.com/aweme/300x400/38a70000fdc960875a10.jpeg","https://pb3.pstatp.com/aweme/300x400/38a70000fdc960875a10.jpeg"],"uri":"300x400/38a70000fdc960875a10"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=dba4c949fe724414b9455dcfb0ecdd20&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=dba4c949fe724414b9455dcfb0ecdd20&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"dba4c949fe724414b9455dcfb0ecdd20"},"origin_cover":{"url_list":["http://p9.pstatp.com/large/38a70000fdc960875a10.jpeg","http://pb1.pstatp.com/large/38a70000fdc960875a10.jpeg","http://pb3.pstatp.com/large/38a70000fdc960875a10.jpeg"],"uri":"large/38a70000fdc960875a10"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=dba4c949fe724414b9455dcfb0ecdd20&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=dba4c949fe724414b9455dcfb0ecdd20&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"dba4c949fe724414b9455dcfb0ecdd20"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/389f0014891aa77d8232","https://pb3.pstatp.com/obj/389f0014891aa77d8232","https://pb3.pstatp.com/obj/389f0014891aa77d8232"],"uri":"389f0014891aa77d8232"}},"aweme_id":"6461552638923115789","video_labels":[{"label_type":3,"label_url":{"url_list":["https://p1.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7"],"uri":"330a000f6d4569feb2f7"}}],"is_vr":false,"vr_type":0,"statistics":{"play_count":13882096,"aweme_id":"6461552638923115789","comment_count":5305,"share_count":31411,"digg_count":418423},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6461552638923115789/?mid=6487814354455825166","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p1.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7"],"uri":"330a000f6d4569feb2f7"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6461552638923115789/?region=CN&mid=6487814354455825166","share_desc":"哈哈，临时跟同学在寝室底下录的😂"},"is_top":0,"label_thumb":{"url_list":["https://p1.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2"],"uri":"2efe004a4a7dc47b3bc2"},"aweme_type":0,"desc":"哈哈，临时跟同学在寝室底下录的😂","region":"","text_extra":[],"user_digged":0}],"desc":"热门挑战"},{"challenge_info":{"schema":"aweme://aweme/challenge/detail?cid=1579886030915598","user_count":348,"author":{},"cha_name":"长得好看","cid":"1579886030915598","type":0,"desc":"什么叫长得好看？"},"aweme_list":[{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":68329625617,"rate":12,"create_time":1506696754,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=4f22a232374e40c98d92bc6a5bc2a1db&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=4f22a232374e40c98d92bc6a5bc2a1db&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"4f22a232374e40c98d92bc6a5bc2a1db"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/3cc4000094af2cdf33af.jpeg","https://pb9.pstatp.com/aweme/300x400/3cc4000094af2cdf33af.jpeg","https://pb3.pstatp.com/aweme/300x400/3cc4000094af2cdf33af.jpeg"],"uri":"300x400/3cc4000094af2cdf33af"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=4f22a232374e40c98d92bc6a5bc2a1db&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=4f22a232374e40c98d92bc6a5bc2a1db&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"4f22a232374e40c98d92bc6a5bc2a1db"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/59ad00108b2c656a8940.jpeg","http://pb9.pstatp.com/large/59ad00108b2c656a8940.jpeg","http://pb3.pstatp.com/large/59ad00108b2c656a8940.jpeg"],"uri":"large/59ad00108b2c656a8940"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=4f22a232374e40c98d92bc6a5bc2a1db&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=4f22a232374e40c98d92bc6a5bc2a1db&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"4f22a232374e40c98d92bc6a5bc2a1db"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/59ad00108b6b5778bdbe","https://pb3.pstatp.com/obj/59ad00108b6b5778bdbe","https://pb3.pstatp.com/obj/59ad00108b6b5778bdbe"],"uri":"59ad00108b6b5778bdbe"}},"aweme_id":"6471213227018554637","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":121566,"aweme_id":"6471213227018554637","comment_count":7,"share_count":57,"digg_count":356},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6471213227018554637/?mid=6448786643015961358","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6471213227018554637/?region=CN&mid=6448786643015961358","share_desc":"好不好看都是本色"},"is_top":0,"aweme_type":0,"desc":"好不好看都是本色","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":76257528084,"rate":12,"create_time":1516100884,"video":{"ratio":"720p","has_watermark":false,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=89decdba61b54231b44d5878934b0428&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=89decdba61b54231b44d5878934b0428&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"89decdba61b54231b44d5878934b0428"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5866001500f4a1b174d6.jpeg","https://pb9.pstatp.com/aweme/300x400/5866001500f4a1b174d6.jpeg","https://pb3.pstatp.com/aweme/300x400/5866001500f4a1b174d6.jpeg"],"uri":"300x400/5866001500f4a1b174d6"},"height":1168,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=89decdba61b54231b44d5878934b0428&line=0&ratio=720p&watermark=0&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=89decdba61b54231b44d5878934b0428&line=1&ratio=720p&watermark=0&media_type=4&vr_type=0"],"uri":"89decdba61b54231b44d5878934b0428"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5869000bdb80b632feb0.jpeg","http://pb9.pstatp.com/large/5869000bdb80b632feb0.jpeg","http://pb3.pstatp.com/large/5869000bdb80b632feb0.jpeg"],"uri":"large/5869000bdb80b632feb0"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=89decdba61b54231b44d5878934b0428&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=89decdba61b54231b44d5878934b0428&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"89decdba61b54231b44d5878934b0428"},"dynamic_cover":{"url_list":["https://p3.pstatp.com/obj/5866001501dd814102ef","https://pb9.pstatp.com/obj/5866001501dd814102ef","https://pb3.pstatp.com/obj/5866001501dd814102ef"],"uri":"5866001501dd814102ef"}},"aweme_id":"6511603668024823053","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":253572,"aweme_id":"6511603668024823053","comment_count":21140,"share_count":629,"digg_count":26667},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6511603668024823053/?mid=6500001936749890318","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6511603668024823053/?region=CN&mid=6500001936749890318","share_desc":"据说这是一条从未失望的抖音，而且还是一条有评论就一定会回复的抖音～不信？那你试试！"},"is_top":0,"aweme_type":0,"desc":"据说这是一条从未失望的抖音，而且还是一条有评论就一定会回复的抖音～不信？那你试试！","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":56036095227,"rate":12,"create_time":1516013714,"video":{"ratio":"720p","has_watermark":false,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=18952e58ad4840f593e79fb2ce01f506&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=18952e58ad4840f593e79fb2ce01f506&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"18952e58ad4840f593e79fb2ce01f506"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/583b000beb49395a6c55.jpeg","https://pb9.pstatp.com/aweme/300x400/583b000beb49395a6c55.jpeg","https://pb3.pstatp.com/aweme/300x400/583b000beb49395a6c55.jpeg"],"uri":"300x400/583b000beb49395a6c55"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=18952e58ad4840f593e79fb2ce01f506&line=0&ratio=720p&watermark=0&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=18952e58ad4840f593e79fb2ce01f506&line=1&ratio=720p&watermark=0&media_type=4&vr_type=0"],"uri":"18952e58ad4840f593e79fb2ce01f506"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/583b000bebc958e26a2d.jpeg","http://pb9.pstatp.com/large/583b000bebc958e26a2d.jpeg","http://pb3.pstatp.com/large/583b000bebc958e26a2d.jpeg"],"uri":"large/583b000bebc958e26a2d"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=18952e58ad4840f593e79fb2ce01f506&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=18952e58ad4840f593e79fb2ce01f506&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"18952e58ad4840f593e79fb2ce01f506"},"dynamic_cover":{"url_list":["https://p3.pstatp.com/obj/5840000109212da4bb21","https://pb9.pstatp.com/obj/5840000109212da4bb21","https://pb3.pstatp.com/obj/5840000109212da4bb21"],"uri":"5840000109212da4bb21"}},"aweme_id":"6511229216648858883","video_labels":[],"is_vr":false,"vr_type":0,"statistics":{"play_count":110738,"aweme_id":"6511229216648858883","comment_count":46,"share_count":155,"digg_count":1791},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6511229216648858883/?mid=6507183496501889795","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6511229216648858883/?region=CN&mid=6507183496501889795","share_desc":"我丑.."},"is_top":0,"aweme_type":0,"desc":"我丑..","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":62526419092,"rate":10,"create_time":1517111046,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=779e2fddecb04346b9014459f686c917&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=779e2fddecb04346b9014459f686c917&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"779e2fddecb04346b9014459f686c917"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5ca6000dbdc37008664e.jpeg","https://pb9.pstatp.com/aweme/300x400/5ca6000dbdc37008664e.jpeg","https://pb3.pstatp.com/aweme/300x400/5ca6000dbdc37008664e.jpeg"],"uri":"300x400/5ca6000dbdc37008664e"},"height":940,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=779e2fddecb04346b9014459f686c917&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=779e2fddecb04346b9014459f686c917&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"779e2fddecb04346b9014459f686c917"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5ca6000dbe2e5f713fbe.jpeg","http://pb9.pstatp.com/large/5ca6000dbe2e5f713fbe.jpeg","http://pb3.pstatp.com/large/5ca6000dbe2e5f713fbe.jpeg"],"uri":"large/5ca6000dbe2e5f713fbe"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=779e2fddecb04346b9014459f686c917&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=779e2fddecb04346b9014459f686c917&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"779e2fddecb04346b9014459f686c917"},"dynamic_cover":{"url_list":["https://p3.pstatp.com/obj/5ca20012afebc06a8ef6","https://pb9.pstatp.com/obj/5ca20012afebc06a8ef6","https://pb3.pstatp.com/obj/5ca20012afebc06a8ef6"],"uri":"5ca20012afebc06a8ef6"}},"aweme_id":"6515942217415134472","video_labels":[],"is_vr":false,"vr_type":0,"statistics":{"play_count":39495,"aweme_id":"6515942217415134472","comment_count":37,"share_count":32,"digg_count":1113},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6515942217415134472/?mid=6515942332394244877","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6515942217415134472/?region=CN&mid=6515942332394244877","share_desc":"喜欢他吗？双击评论你想对他说的话！"},"is_top":0,"aweme_type":0,"desc":"喜欢他吗？双击评论你想对他说的话！","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":72553431593,"rate":12,"create_time":1517206586,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=17cc1d22d08849ed973b71af95eb238f&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=17cc1d22d08849ed973b71af95eb238f&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"17cc1d22d08849ed973b71af95eb238f"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5e9d000dec5c8d8f5cad.jpeg","https://pb9.pstatp.com/aweme/300x400/5e9d000dec5c8d8f5cad.jpeg","https://pb3.pstatp.com/aweme/300x400/5e9d000dec5c8d8f5cad.jpeg"],"uri":"300x400/5e9d000dec5c8d8f5cad"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=17cc1d22d08849ed973b71af95eb238f&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=17cc1d22d08849ed973b71af95eb238f&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"17cc1d22d08849ed973b71af95eb238f"},"origin_cover":{"url_list":["http://p9.pstatp.com/large/5ea00003c5276255fa94.jpeg","http://pb1.pstatp.com/large/5ea00003c5276255fa94.jpeg","http://pb3.pstatp.com/large/5ea00003c5276255fa94.jpeg"],"uri":"large/5ea00003c5276255fa94"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=17cc1d22d08849ed973b71af95eb238f&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=17cc1d22d08849ed973b71af95eb238f&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"17cc1d22d08849ed973b71af95eb238f"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/5ea1000179093bb86f1a","https://pb3.pstatp.com/obj/5ea1000179093bb86f1a","https://pb3.pstatp.com/obj/5ea1000179093bb86f1a"],"uri":"5ea1000179093bb86f1a"}},"aweme_id":"6516352640920587533","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":6758,"aweme_id":"6516352640920587533","comment_count":8,"share_count":1,"digg_count":987},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6516352640920587533/?mid=6448786643015961358","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6516352640920587533/?region=CN&mid=6448786643015961358","share_desc":"容颜都是暂时的，谁都有老去的那一天。心灵美才是永恒。希望能一直保持善良、保持爱❤️💓"},"is_top":0,"aweme_type":0,"desc":"容颜都是暂时的，谁都有老去的那一天。心灵美才是永恒。希望能一直保持善良、保持爱❤️💓","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":21620358330,"rate":12,"create_time":1517311113,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=89800f8eff154d5791633866cead7745&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=89800f8eff154d5791633866cead7745&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"89800f8eff154d5791633866cead7745"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5ee000031f3da5ac4fe1.jpeg","https://pb9.pstatp.com/aweme/300x400/5ee000031f3da5ac4fe1.jpeg","https://pb3.pstatp.com/aweme/300x400/5ee000031f3da5ac4fe1.jpeg"],"uri":"300x400/5ee000031f3da5ac4fe1"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=89800f8eff154d5791633866cead7745&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=89800f8eff154d5791633866cead7745&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"89800f8eff154d5791633866cead7745"},"origin_cover":{"url_list":["http://p9.pstatp.com/large/5edc0010b1ae7b405ed3.jpeg","http://pb1.pstatp.com/large/5edc0010b1ae7b405ed3.jpeg","http://pb3.pstatp.com/large/5edc0010b1ae7b405ed3.jpeg"],"uri":"large/5edc0010b1ae7b405ed3"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=89800f8eff154d5791633866cead7745&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=89800f8eff154d5791633866cead7745&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"89800f8eff154d5791633866cead7745"},"dynamic_cover":{"url_list":["https://p3.pstatp.com/obj/5ede00062dbf5fe10e69","https://pb9.pstatp.com/obj/5ede00062dbf5fe10e69","https://pb3.pstatp.com/obj/5ede00062dbf5fe10e69"],"uri":"5ede00062dbf5fe10e69"}},"aweme_id":"6516801566870080781","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":10599,"aweme_id":"6516801566870080781","comment_count":28,"share_count":5,"digg_count":856},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6516801566870080781/?mid=6507183496501889795","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6516801566870080781/?region=CN&mid=6507183496501889795","share_desc":"不好看但是想录 最后那个真爽我可能录了几十遍就是对不上口型 给我小心心嘛"},"is_top":0,"aweme_type":0,"desc":"不好看但是想录 最后那个真爽我可能录了几十遍就是对不上口型 给我小心心嘛","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":87642667502,"rate":12,"create_time":1516880988,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=384346f131e24ae29f68ece203c8f3d5&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=384346f131e24ae29f68ece203c8f3d5&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"384346f131e24ae29f68ece203c8f3d5"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5c1a0010dcd2004d654c.jpeg","https://pb9.pstatp.com/aweme/300x400/5c1a0010dcd2004d654c.jpeg","https://pb3.pstatp.com/aweme/300x400/5c1a0010dcd2004d654c.jpeg"],"uri":"300x400/5c1a0010dcd2004d654c"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=384346f131e24ae29f68ece203c8f3d5&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=384346f131e24ae29f68ece203c8f3d5&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"384346f131e24ae29f68ece203c8f3d5"},"origin_cover":{"url_list":["http://p1.pstatp.com/large/5c1f0004a5f6e84d151a.jpeg","http://pb3.pstatp.com/large/5c1f0004a5f6e84d151a.jpeg","http://pb3.pstatp.com/large/5c1f0004a5f6e84d151a.jpeg"],"uri":"large/5c1f0004a5f6e84d151a"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=384346f131e24ae29f68ece203c8f3d5&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=384346f131e24ae29f68ece203c8f3d5&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"384346f131e24ae29f68ece203c8f3d5"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/5c20000200fce9e7765c","https://pb3.pstatp.com/obj/5c20000200fce9e7765c","https://pb3.pstatp.com/obj/5c20000200fce9e7765c"],"uri":"5c20000200fce9e7765c"}},"aweme_id":"6514954176575835405","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":27988,"aweme_id":"6514954176575835405","comment_count":13,"share_count":67,"digg_count":449},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6514954176575835405/?mid=6500001936749890318","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6514954176575835405/?region=CN&mid=6500001936749890318","share_desc":"抖音-原创音乐短视频社区"},"is_top":0,"aweme_type":0,"desc":"","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":63024169222,"rate":12,"create_time":1515905931,"video":{"ratio":"720p","has_watermark":false,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=22b5197fccca4c2fbfb8be551618b195&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=22b5197fccca4c2fbfb8be551618b195&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"22b5197fccca4c2fbfb8be551618b195"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/57fa000eadb0392ea4ef.jpeg","https://pb9.pstatp.com/aweme/300x400/57fa000eadb0392ea4ef.jpeg","https://pb3.pstatp.com/aweme/300x400/57fa000eadb0392ea4ef.jpeg"],"uri":"300x400/57fa000eadb0392ea4ef"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=22b5197fccca4c2fbfb8be551618b195&line=0&ratio=720p&watermark=0&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=22b5197fccca4c2fbfb8be551618b195&line=1&ratio=720p&watermark=0&media_type=4&vr_type=0"],"uri":"22b5197fccca4c2fbfb8be551618b195"},"origin_cover":{"url_list":["http://p1.pstatp.com/large/57fd000e8d744d369be4.jpeg","http://pb3.pstatp.com/large/57fd000e8d744d369be4.jpeg","http://pb3.pstatp.com/large/57fd000e8d744d369be4.jpeg"],"uri":"large/57fd000e8d744d369be4"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=22b5197fccca4c2fbfb8be551618b195&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=22b5197fccca4c2fbfb8be551618b195&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"22b5197fccca4c2fbfb8be551618b195"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/57ff000bcc4fb7785726","https://pb3.pstatp.com/obj/57ff000bcc4fb7785726","https://pb3.pstatp.com/obj/57ff000bcc4fb7785726"],"uri":"57ff000bcc4fb7785726"}},"aweme_id":"6510766152782712078","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":39733,"aweme_id":"6510766152782712078","comment_count":18,"share_count":33,"digg_count":331},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6510766152782712078/?mid=6507183496501889795","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6510766152782712078/?region=CN&mid=6507183496501889795","share_desc":"我来迟了🤕"},"is_top":0,"aweme_type":0,"desc":"我来迟了🤕","region":"","text_extra":[],"user_digged":0}],"desc":"热门挑战"}]
     * extra : {"logid":"20180131190004010013046138675C29","now":1517396405122,"fatal_item_ids":[]}
     * has_more : 1
     * status_code : 0
     * cursor : 5
     * device_type : 0
     */

    private ExtraBean extra;
    private int has_more;
    private int status_code;
    private int cursor;
    private int device_type;
    private List<CategoryListBean> category_list;

    public ExtraBean getExtra() {
        return extra;
    }

    public void setExtra(ExtraBean extra) {
        this.extra = extra;
    }

    public int getHas_more() {
        return has_more;
    }

    public void setHas_more(int has_more) {
        this.has_more = has_more;
    }

    public int getStatus_code() {
        return status_code;
    }

    public void setStatus_code(int status_code) {
        this.status_code = status_code;
    }

    public int getCursor() {
        return cursor;
    }

    public void setCursor(int cursor) {
        this.cursor = cursor;
    }

    public int getDevice_type() {
        return device_type;
    }

    public void setDevice_type(int device_type) {
        this.device_type = device_type;
    }

    public List<CategoryListBean> getCategory_list() {
        return category_list;
    }

    public void setCategory_list(List<CategoryListBean> category_list) {
        this.category_list = category_list;
    }

    public static class ExtraBean {
        /**
         * logid : 20180131190004010013046138675C29
         * now : 1517396405122
         * fatal_item_ids : []
         */

        private String logid;
        private long now;
        private List<?> fatal_item_ids;

        public String getLogid() {
            return logid;
        }

        public void setLogid(String logid) {
            this.logid = logid;
        }

        public long getNow() {
            return now;
        }

        public void setNow(long now) {
            this.now = now;
        }

        public List<?> getFatal_item_ids() {
            return fatal_item_ids;
        }

        public void setFatal_item_ids(List<?> fatal_item_ids) {
            this.fatal_item_ids = fatal_item_ids;
        }
    }

    public static class CategoryListBean {
        /**
         * challenge_info : {"schema":"aweme://aweme/challenge/detail?cid=1591086229599236","user_count":16,"author":{},"cha_name":"请你跟我这样做","cid":"1591086229599236","type":0,"desc":"不管你是民族舞小仙女，还是漫画小能手，或者你会钢琴跆拳道花式篮球\u2026\u2026小时候麻麻逼我们学的课外兴趣特长终于有用武之地啦！快来秀出你的独门绝技，请大家跟你一起做，看看你的粉丝有几个能做到并@你的吧！"}
         * aweme_list : [{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":57823035328,"rate":12,"create_time":1517379483,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"6bd1cb90f361468497047aba1d465053"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5efd00112f956366450f.jpeg","https://pb9.pstatp.com/aweme/300x400/5efd00112f956366450f.jpeg","https://pb3.pstatp.com/aweme/300x400/5efd00112f956366450f.jpeg"],"uri":"300x400/5efd00112f956366450f"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"6bd1cb90f361468497047aba1d465053"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5efd00113018f94ddd70.jpeg","http://pb9.pstatp.com/large/5efd00113018f94ddd70.jpeg","http://pb3.pstatp.com/large/5efd00113018f94ddd70.jpeg"],"uri":"large/5efd00113018f94ddd70"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"6bd1cb90f361468497047aba1d465053"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/5f0300005889719acc57","https://pb3.pstatp.com/obj/5f0300005889719acc57","https://pb3.pstatp.com/obj/5f0300005889719acc57"],"uri":"5f0300005889719acc57"}},"aweme_id":"6517093468668431619","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":264154,"aweme_id":"6517093468668431619","comment_count":46,"share_count":241,"digg_count":7574},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6517093468668431619/?mid=6517078237074426637","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6517093468668431619/?region=CN&mid=6517078237074426637","share_desc":"办公室瘦腿大法！请你像我这样做 四个动作 每组1分钟😉 懒人瘦腿必备～ 学会的宝贝记得发视频艾特我交作业哦！"},"is_top":0,"aweme_type":0,"desc":"办公室瘦腿大法！请你像我这样做 四个动作 每组1分钟😉 懒人瘦腿必备～ 学会的宝贝记得发视频艾特我交作业哦！","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":59048261498,"rate":12,"create_time":1517379227,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=719a815b5c10443c8d8a159bba176701&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=719a815b5c10443c8d8a159bba176701&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"719a815b5c10443c8d8a159bba176701"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5efd0010939dd120685f.jpeg","https://pb9.pstatp.com/aweme/300x400/5efd0010939dd120685f.jpeg","https://pb3.pstatp.com/aweme/300x400/5efd0010939dd120685f.jpeg"],"uri":"300x400/5efd0010939dd120685f"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=719a815b5c10443c8d8a159bba176701&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=719a815b5c10443c8d8a159bba176701&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"719a815b5c10443c8d8a159bba176701"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5f010001af17ea6d2d03.jpeg","http://pb9.pstatp.com/large/5f010001af17ea6d2d03.jpeg","http://pb3.pstatp.com/large/5f010001af17ea6d2d03.jpeg"],"uri":"large/5f010001af17ea6d2d03"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=719a815b5c10443c8d8a159bba176701&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=719a815b5c10443c8d8a159bba176701&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"719a815b5c10443c8d8a159bba176701"},"dynamic_cover":{"url_list":["https://p3.pstatp.com/obj/5efe000a5c80f2337cc4","https://pb9.pstatp.com/obj/5efe000a5c80f2337cc4","https://pb3.pstatp.com/obj/5efe000a5c80f2337cc4"],"uri":"5efe000a5c80f2337cc4"}},"aweme_id":"6517094134409334019","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":396395,"aweme_id":"6517094134409334019","comment_count":953,"share_count":153,"digg_count":20994},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6517094134409334019/?mid=6469589389843860237","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6517094134409334019/?region=CN&mid=6469589389843860237","share_desc":"据说好看的人一秒就会。反正我研究了半天😂你花了几秒钟看会的？如果你会就拍个视频艾特我呗🤔我估计你们都会😂"},"is_top":0,"aweme_type":0,"desc":"据说好看的人一秒就会。反正我研究了半天😂你花了几秒钟看会的？如果你会就拍个视频艾特我呗🤔我估计你们都会😂","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":58961282104,"rate":12,"create_time":1517387004,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=4eafb72dbfce413597861dd9941e7df8&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=4eafb72dbfce413597861dd9941e7df8&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"4eafb72dbfce413597861dd9941e7df8"},"cover":{"url_list":["https://p1.pstatp.com/aweme/300x400/5f00001293d9f1d274ae.jpeg","https://pb3.pstatp.com/aweme/300x400/5f00001293d9f1d274ae.jpeg","https://pb3.pstatp.com/aweme/300x400/5f00001293d9f1d274ae.jpeg"],"uri":"300x400/5f00001293d9f1d274ae"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=4eafb72dbfce413597861dd9941e7df8&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=4eafb72dbfce413597861dd9941e7df8&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"4eafb72dbfce413597861dd9941e7df8"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5f0700011b902819cc08.jpeg","http://pb9.pstatp.com/large/5f0700011b902819cc08.jpeg","http://pb3.pstatp.com/large/5f0700011b902819cc08.jpeg"],"uri":"large/5f0700011b902819cc08"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=4eafb72dbfce413597861dd9941e7df8&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=4eafb72dbfce413597861dd9941e7df8&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"4eafb72dbfce413597861dd9941e7df8"},"dynamic_cover":{"url_list":["https://p3.pstatp.com/obj/5f04001055b08f18849e","https://pb9.pstatp.com/obj/5f04001055b08f18849e","https://pb3.pstatp.com/obj/5f04001055b08f18849e"],"uri":"5f04001055b08f18849e"}},"aweme_id":"6517127447316532487","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":22360,"aweme_id":"6517127447316532487","comment_count":98,"share_count":11,"digg_count":349},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6517127447316532487/?mid=6511486777277352708","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6517127447316532487/?region=CN&mid=6511486777277352708","share_desc":"请你跟我这样做，你能做到第几个？评论1 2 3 4 5或者拍视频艾特我证明自己吧！"},"is_top":0,"aweme_type":0,"desc":"请你跟我这样做，你能做到第几个？评论1 2 3 4 5或者拍视频艾特我证明自己吧！","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":58708324458,"rate":12,"create_time":1517381742,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=8e5bd060e7d24ae685359a2c5b72a64e&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=8e5bd060e7d24ae685359a2c5b72a64e&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"8e5bd060e7d24ae685359a2c5b72a64e"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5f020002c97f8150a21f.jpeg","https://pb9.pstatp.com/aweme/300x400/5f020002c97f8150a21f.jpeg","https://pb3.pstatp.com/aweme/300x400/5f020002c97f8150a21f.jpeg"],"uri":"300x400/5f020002c97f8150a21f"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=8e5bd060e7d24ae685359a2c5b72a64e&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=8e5bd060e7d24ae685359a2c5b72a64e&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"8e5bd060e7d24ae685359a2c5b72a64e"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5f010007d4e15fd2c3ab.jpeg","http://pb9.pstatp.com/large/5f010007d4e15fd2c3ab.jpeg","http://pb3.pstatp.com/large/5f010007d4e15fd2c3ab.jpeg"],"uri":"large/5f010007d4e15fd2c3ab"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=8e5bd060e7d24ae685359a2c5b72a64e&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=8e5bd060e7d24ae685359a2c5b72a64e&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"8e5bd060e7d24ae685359a2c5b72a64e"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/5f030005e560ca86897f","https://pb3.pstatp.com/obj/5f030005e560ca86897f","https://pb3.pstatp.com/obj/5f030005e560ca86897f"],"uri":"5f030005e560ca86897f"}},"aweme_id":"6517104895693163779","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":19049,"aweme_id":"6517104895693163779","comment_count":109,"share_count":9,"digg_count":457},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6517104895693163779/?mid=6517104959136205576","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6517104895693163779/?region=CN&mid=6517104959136205576","share_desc":"连麦嘛 我抖音（你们那里今天出太阳了吗？）"},"is_top":0,"aweme_type":0,"desc":"连麦嘛 我抖音（你们那里今天出太阳了吗？）","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":76055758243,"rate":0,"create_time":1517381151,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=048a2b9bbbf84c95a55dd6a8f27ea7a7&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=048a2b9bbbf84c95a55dd6a8f27ea7a7&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"048a2b9bbbf84c95a55dd6a8f27ea7a7"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5efe000f09fdb2ccfabd.jpeg","https://pb9.pstatp.com/aweme/300x400/5efe000f09fdb2ccfabd.jpeg","https://pb3.pstatp.com/aweme/300x400/5efe000f09fdb2ccfabd.jpeg"],"uri":"300x400/5efe000f09fdb2ccfabd"},"height":540,"width":960,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=048a2b9bbbf84c95a55dd6a8f27ea7a7&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=048a2b9bbbf84c95a55dd6a8f27ea7a7&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"048a2b9bbbf84c95a55dd6a8f27ea7a7"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5f030004707859ad6a4d.jpeg","http://pb9.pstatp.com/large/5f030004707859ad6a4d.jpeg","http://pb3.pstatp.com/large/5f030004707859ad6a4d.jpeg"],"uri":"large/5f030004707859ad6a4d"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=048a2b9bbbf84c95a55dd6a8f27ea7a7&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=048a2b9bbbf84c95a55dd6a8f27ea7a7&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"048a2b9bbbf84c95a55dd6a8f27ea7a7"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/5f040001eacf7547883c","https://pb3.pstatp.com/obj/5f040001eacf7547883c","https://pb3.pstatp.com/obj/5f040001eacf7547883c"],"uri":"5f040001eacf7547883c"}},"aweme_id":"6517102359686941956","video_labels":[{"label_type":3,"label_url":{"url_list":["https://p1.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7"],"uri":"330a000f6d4569feb2f7"}}],"is_vr":false,"vr_type":1,"statistics":{"play_count":914508,"aweme_id":"6517102359686941956","comment_count":451,"share_count":542,"digg_count":39968},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6517102359686941956/?mid=6517102446186400516","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p1.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7","https://pb3.pstatp.com/obj/330a000f6d4569feb2f7"],"uri":"330a000f6d4569feb2f7"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6517102359686941956/?region=CN&mid=6517102446186400516","share_desc":"一禅能用编钟敲超级玛丽哦~你又能用什么东西来演奏呢？来和一禅一起演奏吧，别忘了艾特一禅噢！（顺便求个小心心~）"},"is_top":0,"label_thumb":{"url_list":["https://p1.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2"],"uri":"2efe004a4a7dc47b3bc2"},"aweme_type":0,"desc":"一禅能用编钟敲超级玛丽哦~你又能用什么东西来演奏呢？来和一禅一起演奏吧，别忘了艾特一禅噢！（顺便求个小心心~）","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":57757215586,"rate":12,"create_time":1517392896,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=359a8dca6ba543c28efd4b33fba56c32&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=359a8dca6ba543c28efd4b33fba56c32&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"359a8dca6ba543c28efd4b33fba56c32"},"cover":{"url_list":["https://p9.pstatp.com/aweme/300x400/5f07001031f01c21bf41.jpeg","https://pb1.pstatp.com/aweme/300x400/5f07001031f01c21bf41.jpeg","https://pb3.pstatp.com/aweme/300x400/5f07001031f01c21bf41.jpeg"],"uri":"300x400/5f07001031f01c21bf41"},"height":1168,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=359a8dca6ba543c28efd4b33fba56c32&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=359a8dca6ba543c28efd4b33fba56c32&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"359a8dca6ba543c28efd4b33fba56c32"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5f0c000b0f939a5163c5.jpeg","http://pb9.pstatp.com/large/5f0c000b0f939a5163c5.jpeg","http://pb3.pstatp.com/large/5f0c000b0f939a5163c5.jpeg"],"uri":"large/5f0c000b0f939a5163c5"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=359a8dca6ba543c28efd4b33fba56c32&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=359a8dca6ba543c28efd4b33fba56c32&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"359a8dca6ba543c28efd4b33fba56c32"},"dynamic_cover":{"url_list":["https://p3.pstatp.com/obj/5f0f0003da4389c5a98f","https://pb9.pstatp.com/obj/5f0f0003da4389c5a98f","https://pb3.pstatp.com/obj/5f0f0003da4389c5a98f"],"uri":"5f0f0003da4389c5a98f"}},"aweme_id":"6517152788160449795","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":62711,"aweme_id":"6517152788160449795","comment_count":216,"share_count":43,"digg_count":4498},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6517152788160449795/?mid=6517152868603824909","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":true,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6517152788160449795/?region=CN&mid=6517152868603824909","share_desc":"这个结局让我无法接受...你有没有和我一样，越是重要的日子越失眠，然后...迟到、错过...你失眠的时候都干嘛"},"is_top":0,"aweme_type":0,"desc":"这个结局让我无法接受...你有没有和我一样，越是重要的日子越失眠，然后...迟到、错过...你失眠的时候都干嘛","region":"","text_extra":[],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":76065353125,"rate":12,"create_time":1517381045,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=98aa99c7b45a4dc5ae9dad14165bc3e4&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=98aa99c7b45a4dc5ae9dad14165bc3e4&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"98aa99c7b45a4dc5ae9dad14165bc3e4"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5efe000ec6b9da7dcfa3.jpeg","https://pb9.pstatp.com/aweme/300x400/5efe000ec6b9da7dcfa3.jpeg","https://pb3.pstatp.com/aweme/300x400/5efe000ec6b9da7dcfa3.jpeg"],"uri":"300x400/5efe000ec6b9da7dcfa3"},"height":540,"width":960,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=98aa99c7b45a4dc5ae9dad14165bc3e4&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=98aa99c7b45a4dc5ae9dad14165bc3e4&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"98aa99c7b45a4dc5ae9dad14165bc3e4"},"origin_cover":{"url_list":["http://p1.pstatp.com/large/5efe000ec7615dd0a16a.jpeg","http://pb3.pstatp.com/large/5efe000ec7615dd0a16a.jpeg","http://pb3.pstatp.com/large/5efe000ec7615dd0a16a.jpeg"],"uri":"large/5efe000ec7615dd0a16a"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=98aa99c7b45a4dc5ae9dad14165bc3e4&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=98aa99c7b45a4dc5ae9dad14165bc3e4&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"98aa99c7b45a4dc5ae9dad14165bc3e4"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/5eff000de9745d0884db","https://pb3.pstatp.com/obj/5eff000de9745d0884db","https://pb3.pstatp.com/obj/5eff000de9745d0884db"],"uri":"5eff000de9745d0884db"}},"aweme_id":"6517101173009288462","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":30681,"aweme_id":"6517101173009288462","comment_count":17,"share_count":5,"digg_count":655},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6517101173009288462/?mid=6517101972473318158","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6517101173009288462/?region=CN&mid=6517101972473318158","share_desc":"作为舞蹈最棒的我，是时候展现真正的技术了，要不要一起来试试？@抖音小助手"},"is_top":0,"aweme_type":0,"desc":"作为舞蹈最棒的我，是时候展现真正的技术了，要不要一起来试试？@抖音小助手","region":"","text_extra":[{"start":30,"user_id":"6796248446","end":36,"type":0}],"user_digged":0},{"label_top":{"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"},"author_user_id":57395641826,"rate":12,"create_time":1517391961,"video":{"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=d21941d1b607420cb3f9d96a3643b1b2&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=d21941d1b607420cb3f9d96a3643b1b2&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"d21941d1b607420cb3f9d96a3643b1b2"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5f09000b82a6abd1b4d7.jpeg","https://pb9.pstatp.com/aweme/300x400/5f09000b82a6abd1b4d7.jpeg","https://pb3.pstatp.com/aweme/300x400/5f09000b82a6abd1b4d7.jpeg"],"uri":"300x400/5f09000b82a6abd1b4d7"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=d21941d1b607420cb3f9d96a3643b1b2&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=d21941d1b607420cb3f9d96a3643b1b2&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"d21941d1b607420cb3f9d96a3643b1b2"},"origin_cover":{"url_list":["http://p1.pstatp.com/large/5f0a000940a2ee9daf99.jpeg","http://pb3.pstatp.com/large/5f0a000940a2ee9daf99.jpeg","http://pb3.pstatp.com/large/5f0a000940a2ee9daf99.jpeg"],"uri":"large/5f0a000940a2ee9daf99"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=d21941d1b607420cb3f9d96a3643b1b2&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=d21941d1b607420cb3f9d96a3643b1b2&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"d21941d1b607420cb3f9d96a3643b1b2"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/5f0c0008ab8d34e3aa2a","https://pb3.pstatp.com/obj/5f0c0008ab8d34e3aa2a","https://pb3.pstatp.com/obj/5f0c0008ab8d34e3aa2a"],"uri":"5f0c0008ab8d34e3aa2a"}},"aweme_id":"6517148774475762958","video_labels":[],"is_vr":false,"vr_type":1,"statistics":{"play_count":40121,"aweme_id":"6517148774475762958","comment_count":6,"share_count":9,"digg_count":427},"cmt_swt":false,"share_url":"https://www.douyin.com/share/video/6517148774475762958/?mid=6507013908925483789","is_ads":false,"bodydance_score":0,"is_hash_tag":0,"status":{"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false},"label_large":{"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"},"share_info":{"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6517148774475762958/?region=CN&mid=6507013908925483789","share_desc":"一群戏精，像我这样你会吗？会的话，拍个视频艾特我吧～@抖音小助手"},"is_top":0,"aweme_type":0,"desc":"一群戏精，像我这样你会吗？会的话，拍个视频艾特我吧～@抖音小助手","region":"","text_extra":[{"start":26,"user_id":"6796248446","end":32,"type":0}],"user_digged":0}]
         * desc : 热门挑战
         */

        private ChallengeInfoBean challenge_info;
        private String desc;
        private List<AwemeListBean> aweme_list;

        public ChallengeInfoBean getChallenge_info() {
            return challenge_info;
        }

        public void setChallenge_info(ChallengeInfoBean challenge_info) {
            this.challenge_info = challenge_info;
        }

        public String getDesc() {
            return desc;
        }

        public void setDesc(String desc) {
            this.desc = desc;
        }

        public List<AwemeListBean> getAweme_list() {
            return aweme_list;
        }

        public void setAweme_list(List<AwemeListBean> aweme_list) {
            this.aweme_list = aweme_list;
        }

        public static class ChallengeInfoBean {
            /**
             * schema : aweme://aweme/challenge/detail?cid=1591086229599236
             * user_count : 16
             * author : {}
             * cha_name : 请你跟我这样做
             * cid : 1591086229599236
             * type : 0
             * desc : 不管你是民族舞小仙女，还是漫画小能手，或者你会钢琴跆拳道花式篮球……小时候麻麻逼我们学的课外兴趣特长终于有用武之地啦！快来秀出你的独门绝技，请大家跟你一起做，看看你的粉丝有几个能做到并@你的吧！
             */

            private String schema;
            private int user_count;
            private AuthorBean author;
            private String cha_name;
            private String cid;
            private int type;
            private String desc;

            public String getSchema() {
                return schema;
            }

            public void setSchema(String schema) {
                this.schema = schema;
            }

            public int getUser_count() {
                return user_count;
            }

            public void setUser_count(int user_count) {
                this.user_count = user_count;
            }

            public AuthorBean getAuthor() {
                return author;
            }

            public void setAuthor(AuthorBean author) {
                this.author = author;
            }

            public String getCha_name() {
                return cha_name;
            }

            public void setCha_name(String cha_name) {
                this.cha_name = cha_name;
            }

            public String getCid() {
                return cid;
            }

            public void setCid(String cid) {
                this.cid = cid;
            }

            public int getType() {
                return type;
            }

            public void setType(int type) {
                this.type = type;
            }

            public String getDesc() {
                return desc;
            }

            public void setDesc(String desc) {
                this.desc = desc;
            }

            public static class AuthorBean {
            }
        }

        public static class AwemeListBean {
            /**
             * label_top : {"url_list":["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"],"uri":"c150000f34767e2cb56"}
             * author_user_id : 57823035328
             * rate : 12
             * create_time : 1517379483
             * video : {"ratio":"720p","has_watermark":true,"play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"6bd1cb90f361468497047aba1d465053"},"cover":{"url_list":["https://p3.pstatp.com/aweme/300x400/5efd00112f956366450f.jpeg","https://pb9.pstatp.com/aweme/300x400/5efd00112f956366450f.jpeg","https://pb3.pstatp.com/aweme/300x400/5efd00112f956366450f.jpeg"],"uri":"300x400/5efd00112f956366450f"},"height":960,"width":540,"download_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"6bd1cb90f361468497047aba1d465053"},"origin_cover":{"url_list":["http://p3.pstatp.com/large/5efd00113018f94ddd70.jpeg","http://pb9.pstatp.com/large/5efd00113018f94ddd70.jpeg","http://pb3.pstatp.com/large/5efd00113018f94ddd70.jpeg"],"uri":"large/5efd00113018f94ddd70"},"play_addr_lowbr":{"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"6bd1cb90f361468497047aba1d465053"},"dynamic_cover":{"url_list":["https://p1.pstatp.com/obj/5f0300005889719acc57","https://pb3.pstatp.com/obj/5f0300005889719acc57","https://pb3.pstatp.com/obj/5f0300005889719acc57"],"uri":"5f0300005889719acc57"}}
             * aweme_id : 6517093468668431619
             * video_labels : []
             * is_vr : false
             * vr_type : 1
             * statistics : {"play_count":264154,"aweme_id":"6517093468668431619","comment_count":46,"share_count":241,"digg_count":7574}
             * cmt_swt : false
             * share_url : https://www.douyin.com/share/video/6517093468668431619/?mid=6517078237074426637
             * is_ads : false
             * bodydance_score : 0
             * is_hash_tag : 0
             * status : {"allow_share":true,"allow_comment":true,"with_goods":false,"is_private":false,"is_delete":false}
             * label_large : {"url_list":["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"],"uri":"330b000f63e3bf11a1f3"}
             * share_info : {"share_weibo_desc":"#抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>","share_title":"@抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！","share_url":"https://www.douyin.com/share/video/6517093468668431619/?region=CN&mid=6517078237074426637","share_desc":"办公室瘦腿大法！请你像我这样做 四个动作 每组1分钟😉 懒人瘦腿必备～ 学会的宝贝记得发视频艾特我交作业哦！"}
             * is_top : 0
             * aweme_type : 0
             * desc : 办公室瘦腿大法！请你像我这样做 四个动作 每组1分钟😉 懒人瘦腿必备～ 学会的宝贝记得发视频艾特我交作业哦！
             * region :
             * text_extra : []
             * user_digged : 0
             * label_thumb : {"url_list":["https://p1.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2"],"uri":"2efe004a4a7dc47b3bc2"}
             */

            private LabelTopBean label_top;
            private long author_user_id;
            private int rate;
            private int create_time;
            private VideoBean video;
            private String aweme_id;
            private boolean is_vr;
            private int vr_type;
            private StatisticsBean statistics;
            private boolean cmt_swt;
            private String share_url;
            private boolean is_ads;
            private int bodydance_score;
            private int is_hash_tag;
            private StatusBean status;
            private LabelLargeBean label_large;
            private ShareInfoBean share_info;
            private int is_top;
            private int aweme_type;
            private String desc;
            private String region;
            private int user_digged;
            private LabelThumbBean label_thumb;
            private List<?> video_labels;
            private List<?> text_extra;

            public LabelTopBean getLabel_top() {
                return label_top;
            }

            public void setLabel_top(LabelTopBean label_top) {
                this.label_top = label_top;
            }

            public long getAuthor_user_id() {
                return author_user_id;
            }

            public void setAuthor_user_id(long author_user_id) {
                this.author_user_id = author_user_id;
            }

            public int getRate() {
                return rate;
            }

            public void setRate(int rate) {
                this.rate = rate;
            }

            public int getCreate_time() {
                return create_time;
            }

            public void setCreate_time(int create_time) {
                this.create_time = create_time;
            }

            public VideoBean getVideo() {
                return video;
            }

            public void setVideo(VideoBean video) {
                this.video = video;
            }

            public String getAweme_id() {
                return aweme_id;
            }

            public void setAweme_id(String aweme_id) {
                this.aweme_id = aweme_id;
            }

            public boolean isIs_vr() {
                return is_vr;
            }

            public void setIs_vr(boolean is_vr) {
                this.is_vr = is_vr;
            }

            public int getVr_type() {
                return vr_type;
            }

            public void setVr_type(int vr_type) {
                this.vr_type = vr_type;
            }

            public StatisticsBean getStatistics() {
                return statistics;
            }

            public void setStatistics(StatisticsBean statistics) {
                this.statistics = statistics;
            }

            public boolean isCmt_swt() {
                return cmt_swt;
            }

            public void setCmt_swt(boolean cmt_swt) {
                this.cmt_swt = cmt_swt;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public boolean isIs_ads() {
                return is_ads;
            }

            public void setIs_ads(boolean is_ads) {
                this.is_ads = is_ads;
            }

            public int getBodydance_score() {
                return bodydance_score;
            }

            public void setBodydance_score(int bodydance_score) {
                this.bodydance_score = bodydance_score;
            }

            public int getIs_hash_tag() {
                return is_hash_tag;
            }

            public void setIs_hash_tag(int is_hash_tag) {
                this.is_hash_tag = is_hash_tag;
            }

            public StatusBean getStatus() {
                return status;
            }

            public void setStatus(StatusBean status) {
                this.status = status;
            }

            public LabelLargeBean getLabel_large() {
                return label_large;
            }

            public void setLabel_large(LabelLargeBean label_large) {
                this.label_large = label_large;
            }

            public ShareInfoBean getShare_info() {
                return share_info;
            }

            public void setShare_info(ShareInfoBean share_info) {
                this.share_info = share_info;
            }

            public int getIs_top() {
                return is_top;
            }

            public void setIs_top(int is_top) {
                this.is_top = is_top;
            }

            public int getAweme_type() {
                return aweme_type;
            }

            public void setAweme_type(int aweme_type) {
                this.aweme_type = aweme_type;
            }

            public String getDesc() {
                return desc;
            }

            public void setDesc(String desc) {
                this.desc = desc;
            }

            public String getRegion() {
                return region;
            }

            public void setRegion(String region) {
                this.region = region;
            }

            public int getUser_digged() {
                return user_digged;
            }

            public void setUser_digged(int user_digged) {
                this.user_digged = user_digged;
            }

            public LabelThumbBean getLabel_thumb() {
                return label_thumb;
            }

            public void setLabel_thumb(LabelThumbBean label_thumb) {
                this.label_thumb = label_thumb;
            }

            public List<?> getVideo_labels() {
                return video_labels;
            }

            public void setVideo_labels(List<?> video_labels) {
                this.video_labels = video_labels;
            }

            public List<?> getText_extra() {
                return text_extra;
            }

            public void setText_extra(List<?> text_extra) {
                this.text_extra = text_extra;
            }

            public static class LabelTopBean {
                /**
                 * url_list : ["https://p3.pstatp.com/obj/c150000f34767e2cb56","https://pb9.pstatp.com/obj/c150000f34767e2cb56","https://pb3.pstatp.com/obj/c150000f34767e2cb56"]
                 * uri : c150000f34767e2cb56
                 */

                private String uri;
                private List<String> url_list;

                public String getUri() {
                    return uri;
                }

                public void setUri(String uri) {
                    this.uri = uri;
                }

                public List<String> getUrl_list() {
                    return url_list;
                }

                public void setUrl_list(List<String> url_list) {
                    this.url_list = url_list;
                }
            }

            public static class VideoBean {
                /**
                 * ratio : 720p
                 * has_watermark : true
                 * play_addr : {"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"6bd1cb90f361468497047aba1d465053"}
                 * cover : {"url_list":["https://p3.pstatp.com/aweme/300x400/5efd00112f956366450f.jpeg","https://pb9.pstatp.com/aweme/300x400/5efd00112f956366450f.jpeg","https://pb3.pstatp.com/aweme/300x400/5efd00112f956366450f.jpeg"],"uri":"300x400/5efd00112f956366450f"}
                 * height : 960
                 * width : 540
                 * download_addr : {"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"],"uri":"6bd1cb90f361468497047aba1d465053"}
                 * origin_cover : {"url_list":["http://p3.pstatp.com/large/5efd00113018f94ddd70.jpeg","http://pb9.pstatp.com/large/5efd00113018f94ddd70.jpeg","http://pb3.pstatp.com/large/5efd00113018f94ddd70.jpeg"],"uri":"large/5efd00113018f94ddd70"}
                 * play_addr_lowbr : {"url_list":["https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=1&ratio=720p&media_type=4&vr_type=0"],"uri":"6bd1cb90f361468497047aba1d465053"}
                 * dynamic_cover : {"url_list":["https://p1.pstatp.com/obj/5f0300005889719acc57","https://pb3.pstatp.com/obj/5f0300005889719acc57","https://pb3.pstatp.com/obj/5f0300005889719acc57"],"uri":"5f0300005889719acc57"}
                 */

                private String ratio;
                private boolean has_watermark;
                private PlayAddrBean play_addr;
                private CoverBean cover;
                private int height;
                private int width;
                private DownloadAddrBean download_addr;
                private OriginCoverBean origin_cover;
                private PlayAddrLowbrBean play_addr_lowbr;
                private DynamicCoverBean dynamic_cover;

                public String getRatio() {
                    return ratio;
                }

                public void setRatio(String ratio) {
                    this.ratio = ratio;
                }

                public boolean isHas_watermark() {
                    return has_watermark;
                }

                public void setHas_watermark(boolean has_watermark) {
                    this.has_watermark = has_watermark;
                }

                public PlayAddrBean getPlay_addr() {
                    return play_addr;
                }

                public void setPlay_addr(PlayAddrBean play_addr) {
                    this.play_addr = play_addr;
                }

                public CoverBean getCover() {
                    return cover;
                }

                public void setCover(CoverBean cover) {
                    this.cover = cover;
                }

                public int getHeight() {
                    return height;
                }

                public void setHeight(int height) {
                    this.height = height;
                }

                public int getWidth() {
                    return width;
                }

                public void setWidth(int width) {
                    this.width = width;
                }

                public DownloadAddrBean getDownload_addr() {
                    return download_addr;
                }

                public void setDownload_addr(DownloadAddrBean download_addr) {
                    this.download_addr = download_addr;
                }

                public OriginCoverBean getOrigin_cover() {
                    return origin_cover;
                }

                public void setOrigin_cover(OriginCoverBean origin_cover) {
                    this.origin_cover = origin_cover;
                }

                public PlayAddrLowbrBean getPlay_addr_lowbr() {
                    return play_addr_lowbr;
                }

                public void setPlay_addr_lowbr(PlayAddrLowbrBean play_addr_lowbr) {
                    this.play_addr_lowbr = play_addr_lowbr;
                }

                public DynamicCoverBean getDynamic_cover() {
                    return dynamic_cover;
                }

                public void setDynamic_cover(DynamicCoverBean dynamic_cover) {
                    this.dynamic_cover = dynamic_cover;
                }

                public static class PlayAddrBean {
                    /**
                     * url_list : ["https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=1&ratio=720p&media_type=4&vr_type=0"]
                     * uri : 6bd1cb90f361468497047aba1d465053
                     */

                    private String uri;
                    private List<String> url_list;

                    public String getUri() {
                        return uri;
                    }

                    public void setUri(String uri) {
                        this.uri = uri;
                    }

                    public List<String> getUrl_list() {
                        return url_list;
                    }

                    public void setUrl_list(List<String> url_list) {
                        this.url_list = url_list;
                    }
                }

                public static class CoverBean {
                    /**
                     * url_list : ["https://p3.pstatp.com/aweme/300x400/5efd00112f956366450f.jpeg","https://pb9.pstatp.com/aweme/300x400/5efd00112f956366450f.jpeg","https://pb3.pstatp.com/aweme/300x400/5efd00112f956366450f.jpeg"]
                     * uri : 300x400/5efd00112f956366450f
                     */

                    private String uri;
                    private List<String> url_list;

                    public String getUri() {
                        return uri;
                    }

                    public void setUri(String uri) {
                        this.uri = uri;
                    }

                    public List<String> getUrl_list() {
                        return url_list;
                    }

                    public void setUrl_list(List<String> url_list) {
                        this.url_list = url_list;
                    }
                }

                public static class DownloadAddrBean {
                    /**
                     * url_list : ["https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=0&ratio=720p&watermark=1&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=1&ratio=720p&watermark=1&media_type=4&vr_type=0"]
                     * uri : 6bd1cb90f361468497047aba1d465053
                     */

                    private String uri;
                    private List<String> url_list;

                    public String getUri() {
                        return uri;
                    }

                    public void setUri(String uri) {
                        this.uri = uri;
                    }

                    public List<String> getUrl_list() {
                        return url_list;
                    }

                    public void setUrl_list(List<String> url_list) {
                        this.url_list = url_list;
                    }
                }

                public static class OriginCoverBean {
                    /**
                     * url_list : ["http://p3.pstatp.com/large/5efd00113018f94ddd70.jpeg","http://pb9.pstatp.com/large/5efd00113018f94ddd70.jpeg","http://pb3.pstatp.com/large/5efd00113018f94ddd70.jpeg"]
                     * uri : large/5efd00113018f94ddd70
                     */

                    private String uri;
                    private List<String> url_list;

                    public String getUri() {
                        return uri;
                    }

                    public void setUri(String uri) {
                        this.uri = uri;
                    }

                    public List<String> getUrl_list() {
                        return url_list;
                    }

                    public void setUrl_list(List<String> url_list) {
                        this.url_list = url_list;
                    }
                }

                public static class PlayAddrLowbrBean {
                    /**
                     * url_list : ["https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=0&ratio=720p&media_type=4&vr_type=0","https://aweme.snssdk.com/aweme/v1/play/?video_id=6bd1cb90f361468497047aba1d465053&line=1&ratio=720p&media_type=4&vr_type=0"]
                     * uri : 6bd1cb90f361468497047aba1d465053
                     */

                    private String uri;
                    private List<String> url_list;

                    public String getUri() {
                        return uri;
                    }

                    public void setUri(String uri) {
                        this.uri = uri;
                    }

                    public List<String> getUrl_list() {
                        return url_list;
                    }

                    public void setUrl_list(List<String> url_list) {
                        this.url_list = url_list;
                    }
                }

                public static class DynamicCoverBean {
                    /**
                     * url_list : ["https://p1.pstatp.com/obj/5f0300005889719acc57","https://pb3.pstatp.com/obj/5f0300005889719acc57","https://pb3.pstatp.com/obj/5f0300005889719acc57"]
                     * uri : 5f0300005889719acc57
                     */

                    private String uri;
                    private List<String> url_list;

                    public String getUri() {
                        return uri;
                    }

                    public void setUri(String uri) {
                        this.uri = uri;
                    }

                    public List<String> getUrl_list() {
                        return url_list;
                    }

                    public void setUrl_list(List<String> url_list) {
                        this.url_list = url_list;
                    }
                }
            }

            public static class StatisticsBean {
                /**
                 * play_count : 264154
                 * aweme_id : 6517093468668431619
                 * comment_count : 46
                 * share_count : 241
                 * digg_count : 7574
                 */

                private int play_count;
                private String aweme_id;
                private int comment_count;
                private int share_count;
                private int digg_count;

                public int getPlay_count() {
                    return play_count;
                }

                public void setPlay_count(int play_count) {
                    this.play_count = play_count;
                }

                public String getAweme_id() {
                    return aweme_id;
                }

                public void setAweme_id(String aweme_id) {
                    this.aweme_id = aweme_id;
                }

                public int getComment_count() {
                    return comment_count;
                }

                public void setComment_count(int comment_count) {
                    this.comment_count = comment_count;
                }

                public int getShare_count() {
                    return share_count;
                }

                public void setShare_count(int share_count) {
                    this.share_count = share_count;
                }

                public int getDigg_count() {
                    return digg_count;
                }

                public void setDigg_count(int digg_count) {
                    this.digg_count = digg_count;
                }
            }

            public static class StatusBean {
                /**
                 * allow_share : true
                 * allow_comment : true
                 * with_goods : false
                 * is_private : false
                 * is_delete : false
                 */

                private boolean allow_share;
                private boolean allow_comment;
                private boolean with_goods;
                private boolean is_private;
                private boolean is_delete;

                public boolean isAllow_share() {
                    return allow_share;
                }

                public void setAllow_share(boolean allow_share) {
                    this.allow_share = allow_share;
                }

                public boolean isAllow_comment() {
                    return allow_comment;
                }

                public void setAllow_comment(boolean allow_comment) {
                    this.allow_comment = allow_comment;
                }

                public boolean isWith_goods() {
                    return with_goods;
                }

                public void setWith_goods(boolean with_goods) {
                    this.with_goods = with_goods;
                }

                public boolean isIs_private() {
                    return is_private;
                }

                public void setIs_private(boolean is_private) {
                    this.is_private = is_private;
                }

                public boolean isIs_delete() {
                    return is_delete;
                }

                public void setIs_delete(boolean is_delete) {
                    this.is_delete = is_delete;
                }
            }

            public static class LabelLargeBean {
                /**
                 * url_list : ["https://p9.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb1.pstatp.com/obj/330b000f63e3bf11a1f3","https://pb3.pstatp.com/obj/330b000f63e3bf11a1f3"]
                 * uri : 330b000f63e3bf11a1f3
                 */

                private String uri;
                private List<String> url_list;

                public String getUri() {
                    return uri;
                }

                public void setUri(String uri) {
                    this.uri = uri;
                }

                public List<String> getUrl_list() {
                    return url_list;
                }

                public void setUrl_list(List<String> url_list) {
                    this.url_list = url_list;
                }
            }

            public static class ShareInfoBean {
                /**
                 * share_weibo_desc : #抖音上瘾# @抖音玩家 发了一个抖音短视频，你尽管点开，不好看算我输！戳这里>>
                 * share_title : @抖音玩家发了一个抖音短视频，你尽管点开，不好看算我输！
                 * share_url : https://www.douyin.com/share/video/6517093468668431619/?region=CN&mid=6517078237074426637
                 * share_desc : 办公室瘦腿大法！请你像我这样做 四个动作 每组1分钟😉 懒人瘦腿必备～ 学会的宝贝记得发视频艾特我交作业哦！
                 */

                private String share_weibo_desc;
                private String share_title;
                private String share_url;
                private String share_desc;

                public String getShare_weibo_desc() {
                    return share_weibo_desc;
                }

                public void setShare_weibo_desc(String share_weibo_desc) {
                    this.share_weibo_desc = share_weibo_desc;
                }

                public String getShare_title() {
                    return share_title;
                }

                public void setShare_title(String share_title) {
                    this.share_title = share_title;
                }

                public String getShare_url() {
                    return share_url;
                }

                public void setShare_url(String share_url) {
                    this.share_url = share_url;
                }

                public String getShare_desc() {
                    return share_desc;
                }

                public void setShare_desc(String share_desc) {
                    this.share_desc = share_desc;
                }
            }

            public static class LabelThumbBean {
                /**
                 * url_list : ["https://p1.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2","https://pb3.pstatp.com/obj/2efe004a4a7dc47b3bc2"]
                 * uri : 2efe004a4a7dc47b3bc2
                 */

                private String uri;
                private List<String> url_list;

                public String getUri() {
                    return uri;
                }

                public void setUri(String uri) {
                    this.uri = uri;
                }

                public List<String> getUrl_list() {
                    return url_list;
                }

                public void setUrl_list(List<String> url_list) {
                    this.url_list = url_list;
                }
            }
        }
    }
}
